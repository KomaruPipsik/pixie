const express = require('express');
const router = express.Router();
const { getDb } = require('../models/db');
const { authMiddleware } = require('../middleware/auth');
const { holdFunds, releaseFunds, refundFunds } = require('../models/payment');
const { createNotification } = require('../models/notification');
const { sendToUser } = require('../middleware/websocket');

// GET /api/tasks  — active tasks (exclude own)
router.get('/', authMiddleware, (req, res) => {
  const { city, school } = req.query;
  const db = getDb();
  let q = `SELECT t.*, u.nickname as creator_nickname FROM tasks t JOIN users u ON t.creator_id = u.id WHERE t.status = 'active' AND t.creator_id != ?`;
  const p = [req.user.id];
  if (city)   { q += ' AND t.city = ?';   p.push(city); }
  if (school) { q += ' AND t.school = ?'; p.push(school); }
  q += ' ORDER BY t.created_at DESC';
  res.json({ tasks: db.prepare(q).all(...p) });
});

// GET /api/tasks/my
router.get('/my', authMiddleware, (req, res) => {
  const db = getDb();
  const tasks = db.prepare(`
    SELECT t.*, c.nickname as creator_nickname, e.nickname as executor_nickname
    FROM tasks t
    JOIN users c ON t.creator_id = c.id
    LEFT JOIN users e ON t.executor_id = e.id
    WHERE t.creator_id = ? OR t.executor_id = ?
    ORDER BY t.updated_at DESC
  `).all(req.user.id, req.user.id);
  res.json({ tasks });
});

// GET /api/tasks/:id
router.get('/:id', authMiddleware, (req, res) => {
  const db = getDb();
  const task = db.prepare(`
    SELECT t.*, c.nickname as creator_nickname, e.nickname as executor_nickname, m.nickname as moderator_nickname
    FROM tasks t
    JOIN users c ON t.creator_id = c.id
    LEFT JOIN users e ON t.executor_id = e.id
    LEFT JOIN users m ON t.moderator_id = m.id
    WHERE t.id = ?
  `).get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  res.json({ task });
});

// POST /api/tasks — create
router.post('/', authMiddleware, (req, res) => {
  const { title, description, city, school, amount } = req.body;
  if (!title || !description || !city || !school || !amount) return res.status(400).json({ error: 'Всі поля обов\'язкові' });
  if (parseFloat(amount) < 10) return res.status(400).json({ error: 'Мінімальна сума — 10 грн' });
  const db = getDb();
  const cnt = db.prepare(`SELECT COUNT(*) as c FROM tasks WHERE creator_id = ? AND status NOT IN ('completed','rejected','expired')`).get(req.user.id);
  if (cnt.c >= 5) return res.status(400).json({ error: 'Не можна створити більше 5 активних завдань одночасно' });
  const result = db.prepare(`INSERT INTO tasks (creator_id, title, description, city, school, amount, status) VALUES (?,?,?,?,?,?,'pending_moderation')`)
    .run(req.user.id, title.trim(), description.trim(), city, school, parseFloat(amount));
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(result.lastInsertRowid);
  assignModerator(task.id);
  res.status(201).json({ task, message: 'Завдання відправлено на модерацію' });
});

// POST /api/tasks/:id/pay
router.post('/:id/pay', authMiddleware, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (task.creator_id !== req.user.id) return res.status(403).json({ error: 'Немає доступу' });
  if (task.status !== 'approved_awaiting_payment') return res.status(400).json({ error: 'Завдання не очікує оплати' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user.card_number) return res.status(400).json({ error: 'Прив\'яжіть банківську карту в налаштуваннях профілю' });
  const pay = holdFunds(task.id, user.id, task.amount, user.card_number);
  if (!pay.success) return res.status(402).json({ error: pay.error });
  const expiresAt = new Date(Date.now() + 48 * 3600000).toISOString();
  db.prepare(`UPDATE tasks SET status='active', held_amount=?, timer_expires_at=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(task.amount, expiresAt, task.id);
  res.json({ message: 'Оплата пройшла! Завдання опубліковано.', expiresAt });
});

// POST /api/tasks/:id/take
router.post('/:id/take', authMiddleware, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (task.status !== 'active') return res.status(400).json({ error: 'Завдання недоступне' });
  if (task.creator_id === req.user.id) return res.status(400).json({ error: 'Не можна взяти своє завдання' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user.card_number) return res.status(400).json({ error: 'Прив\'яжіть банківську карту для отримання оплати' });
  db.prepare(`UPDATE tasks SET status='in_progress', executor_id=?, timer_expires_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(req.user.id, task.id);
  createNotification(task.creator_id, '🚀 Ваше завдання взято в роботу!',
    `"${user.nickname}" взяв завдання "${task.title}"`, 'task', task.id);
  db.prepare(`INSERT INTO messages (task_id, type, content) VALUES (?, 'system', ?)`).run(task.id, `${user.nickname} взяв завдання в роботу`);
  res.json({ message: 'Завдання взято в роботу', taskId: task.id });
});

// POST /api/tasks/:id/confirm
router.post('/:id/confirm', authMiddleware, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (task.status !== 'pending_confirmation') return res.status(400).json({ error: 'Завдання не очікує підтвердження' });
  if (task.creator_id !== req.user.id && task.executor_id !== req.user.id) return res.status(403).json({ error: 'Немає доступу' });

  if (task.creator_id === req.user.id) {
    const executor = db.prepare('SELECT * FROM users WHERE id = ?').get(task.executor_id);
    const owner = db.prepare("SELECT * FROM users WHERE role = 'owner'").get();
    const pay = releaseFunds(task.id, task.executor_id, owner.id, task.held_amount, executor.card_number, owner.card_number);
    db.prepare(`UPDATE tasks SET status='completed', updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
    createNotification(task.executor_id, '✅ Завдання завершено! Оплата відправлена',
      `Замовник підтвердив виконання "${task.title}". Вам нараховано ${pay.executorAmount} грн.`, 'payment', task.id);
    db.prepare(`INSERT INTO messages (task_id, type, content) VALUES (?, 'system', ?)`).run(task.id, `Завдання виконано! Виконавцю нараховано ${pay.executorAmount} грн.`);
    return res.json({ message: 'Завдання завершено, оплата надіслана', ...pay });
  }
  res.json({ message: 'Ви підтвердили виконання. Очікуйте підтвердження замовника.' });
});

// POST /api/tasks/:id/reject
router.post('/:id/reject', authMiddleware, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (task.creator_id !== req.user.id) return res.status(403).json({ error: 'Немає доступу' });
  if (task.status !== 'pending_confirmation') return res.status(400).json({ error: 'Немає відео для перевірки' });
  const appealExpires = new Date(Date.now() + 24 * 3600000).toISOString();
  db.prepare(`UPDATE tasks SET status='in_progress', appeal_expires_at=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(appealExpires, task.id);
  createNotification(task.executor_id, '❌ Замовник відхилив відео',
    `Замовник відхилив ваше відео по "${task.title}". У вас є 24 години для апеляції.`, 'task', task.id);
  db.prepare(`INSERT INTO messages (task_id, type, content) VALUES (?, 'system', ?)`).run(task.id, 'Замовник відхилив відео. Виконавець може подати апеляцію протягом 24 годин.');
  res.json({ message: 'Відхилено. Виконавця повідомлено.', appealExpires });
});

// POST /api/tasks/:id/appeal
router.post('/:id/appeal', authMiddleware, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (task.executor_id !== req.user.id) return res.status(403).json({ error: 'Немає доступу' });
  if (task.status !== 'in_progress') return res.status(400).json({ error: 'Апеляція недоступна' });
  if (!task.appeal_expires_at || new Date(task.appeal_expires_at) < new Date())
    return res.status(400).json({ error: 'Час для апеляції вийшов' });
  const disputeExpires = new Date(Date.now() + 48 * 3600000).toISOString();
  db.prepare(`UPDATE tasks SET status='disputed', dispute_expires_at=?, appeal_expires_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(disputeExpires, task.id);
  const mods = db.prepare("SELECT id FROM users WHERE role IN ('moderator','owner')").all();
  mods.forEach(m => createNotification(m.id, '⚖️ Новий спір потребує розгляду',
    `Спір по завданню "${task.title}" (ID: ${task.id}). Необхідно прийняти рішення протягом 48 годин.`, 'dispute', task.id));
  db.prepare(`INSERT INTO messages (task_id, type, content) VALUES (?, 'system', ?)`).run(task.id, 'Виконавець подав апеляцію. Спір передано модераторам.');
  res.json({ message: 'Апеляцію подано. Модератори розглянуть протягом 48 годин.', disputeExpires });
});

function assignModerator(taskId) {
  const db = getDb();
  const mod = db.prepare(`
    SELECT u.id FROM users u
    WHERE u.role IN ('moderator','owner')
    AND u.id NOT IN (SELECT COALESCE(moderator_id,0) FROM tasks WHERE status='on_moderation' AND moderator_id IS NOT NULL)
    LIMIT 1
  `).get();
  if (mod) {
    db.prepare(`UPDATE tasks SET status='on_moderation', moderator_id=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(mod.id, taskId);
    const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    createNotification(mod.id, '📋 Нове завдання на перевірку', `Завдання "${task.title}" очікує вашої перевірки.`, 'task', taskId);
  }
}

module.exports = router;
module.exports.assignModerator = assignModerator;
