const express = require('express');
const router = express.Router();
const { getDb } = require('../models/db');
const { authMiddleware } = require('../middleware/auth');

router.put('/', authMiddleware, (req, res) => {
  const { city, school, card_number } = req.body;
  const db = getDb();
  const updates = []; const values = [];
  if (city !== undefined) { updates.push('city = ?'); values.push(city); }
  if (school !== undefined) { updates.push('school = ?'); values.push(school); }
  if (card_number !== undefined) {
    const cleaned = card_number ? card_number.replace(/\s/g, '') : null;
    if (cleaned && !/^\d{16}$/.test(cleaned)) return res.status(400).json({ error: 'Номер карти: 16 цифр' });
    updates.push('card_number = ?'); values.push(cleaned);
  }
  if (!updates.length) return res.status(400).json({ error: 'Немає даних для оновлення' });
  values.push(req.user.id);
  db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json({ user: {
    id: user.id, nickname: user.nickname, role: user.role,
    city: user.city, school: user.school,
    hasCard: !!user.card_number,
    cardMasked: user.card_number ? '**** **** **** ' + String(user.card_number).slice(-4) : null,
    createdAt: user.created_at
  }});
});

module.exports = router;
