const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getDb } = require('../models/db');
const { authMiddleware } = require('../middleware/auth');

function sanitizeUser(user) {
  if (!user) return null;
  return {
    id: user.id, nickname: user.nickname, role: user.role,
    city: user.city, school: user.school,
    hasCard: !!user.card_number,
    cardMasked: user.card_number ? '**** **** **** ' + String(user.card_number).slice(-4) : null,
    createdAt: user.created_at
  };
}

router.post('/register', (req, res) => {
  const { nickname, password } = req.body;
  if (!nickname || !password) return res.status(400).json({ error: 'Нікнейм і пароль обов\'язкові' });
  if (nickname.length < 3 || nickname.length > 30) return res.status(400).json({ error: 'Нікнейм: від 3 до 30 символів' });
  if (password.length < 6) return res.status(400).json({ error: 'Пароль мінімум 6 символів' });
  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE nickname = ?').get(nickname);
  if (existing) return res.status(409).json({ error: 'Цей нікнейм вже зайнятий, придумайте інший' });
  const hash = bcrypt.hashSync(password, 10);
  const result = db.prepare(`INSERT INTO users (nickname, password_hash, role) VALUES (?, ?, 'user')`).run(nickname, hash);
  const userId = result.lastInsertRowid;
  const token = jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '30d' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  res.status(201).json({ token, user: sanitizeUser(user) });
});

router.post('/login', (req, res) => {
  const { nickname, password } = req.body;
  if (!nickname || !password) return res.status(400).json({ error: 'Нікнейм і пароль обов\'язкові' });
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE nickname = ?').get(nickname);
  if (!user || !bcrypt.compareSync(password, user.password_hash))
    return res.status(401).json({ error: 'Невірний нікнейм або пароль' });
  const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: sanitizeUser(user) });
});

router.get('/me', authMiddleware, (req, res) => {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json({ user: sanitizeUser(user) });
});

module.exports = router;
