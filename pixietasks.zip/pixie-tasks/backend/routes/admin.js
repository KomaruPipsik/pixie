const express = require('express');
const router = express.Router();
const { getDb } = require('../models/db');
const { authMiddleware, requireRole } = require('../middleware/auth');
const isOwner = requireRole('owner');

router.get('/users', authMiddleware, isOwner, (req, res) => {
  const db = getDb();
  const users = db.prepare(`SELECT id, nickname, role, city, school, card_number, created_at FROM users ORDER BY created_at DESC`).all();
  res.json({ users: users.map(u => ({ ...u, card_masked: u.card_number ? '**** **** **** ' + String(u.card_number).slice(-4) : null, card_number: undefined })) });
});

router.put('/users/:id/role', authMiddleware, isOwner, (req, res) => {
  const { role } = req.body;
  if (!['user','moderator'].includes(role)) return res.status(400).json({ error: 'Допустимі ролі: user, moderator' });
  const db = getDb();
  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.params.id);
  res.json({ message: 'Роль оновлено' });
});

router.get('/stats', authMiddleware, isOwner, (req, res) => {
  const db = getDb();
  const q = (sql, ...p) => db.prepare(sql).get(...p);
  res.json({
    totalUsers: q("SELECT COUNT(*) as c FROM users WHERE role = 'user'").c,
    totalTasks: q("SELECT COUNT(*) as c FROM tasks").c,
    activeTasks: q("SELECT COUNT(*) as c FROM tasks WHERE status = 'active'").c,
    completedTasks: q("SELECT COUNT(*) as c FROM tasks WHERE status = 'completed'").c,
    disputedTasks: q("SELECT COUNT(*) as c FROM tasks WHERE status = 'disputed'").c,
    totalCommission: q("SELECT COALESCE(SUM(amount),0) as c FROM payments WHERE type='commission' AND status='completed'").c,
  });
});

module.exports = router;
