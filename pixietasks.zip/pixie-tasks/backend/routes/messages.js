const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const { getDb } = require('../models/db');
const { authMiddleware } = require('../middleware/auth');
const { createNotification } = require('../models/notification');
const { sendToUser } = require('../middleware/websocket');

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, `${uuidv4()}${path.extname(file.originalname)}`)
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (['video/mp4','video/webm','video/quicktime','video/mpeg'].includes(file.mimetype)) cb(null, true);
    else cb(new Error('Тільки відео файли'));
  }
});

function canAccess(task, userId) {
  if (!task) return false;
  if (task.creator_id === userId || task.executor_id === userId) return true;
  const db = getDb();
  const u = db.prepare("SELECT id FROM users WHERE id = ? AND role IN ('moderator','owner')").get(userId);
  return !!u;
}

router.get('/:taskId', authMiddleware, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.taskId);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (!canAccess(task, req.user.id)) return res.status(403).json({ error: 'Немає доступу до чату' });
  const messages = db.prepare(`
    SELECT m.*, u.nickname as sender_nickname FROM messages m
    LEFT JOIN users u ON m.sender_id = u.id
    WHERE m.task_id = ? ORDER BY m.created_at ASC
  `).all(req.params.taskId);
  res.json({ messages });
});

router.post('/:taskId', authMiddleware, (req, res) => {
  const { content } = req.body;
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.taskId);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (!canAccess(task, req.user.id)) return res.status(403).json({ error: 'Немає доступу' });
  if (!content || !content.trim()) return res.status(400).json({ error: 'Порожнє повідомлення' });
  const result = db.prepare(`INSERT INTO messages (task_id, sender_id, content, type) VALUES (?, ?, ?, 'text')`).run(task.id, req.user.id, content.trim());
  const message = db.prepare(`SELECT m.*, u.nickname as sender_nickname FROM messages m LEFT JOIN users u ON m.sender_id=u.id WHERE m.id=?`).get(result.lastInsertRowid);
  const recipientId = task.creator_id === req.user.id ? task.executor_id : task.creator_id;
  if (recipientId) {
    sendToUser(recipientId, { type: 'new_message', message, taskId: task.id });
    createNotification(recipientId, '💬 Нове повідомлення', `${req.user.nickname}: ${content.trim().slice(0,80)}`, 'task', task.id);
  }
  res.status(201).json({ message });
});

router.post('/:taskId/video', authMiddleware, upload.single('video'), (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.taskId);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  if (task.executor_id !== req.user.id) return res.status(403).json({ error: 'Тільки виконавець може завантажувати відео' });
  const videoUrl = req.file ? `/uploads/${req.file.filename}` : null;
  db.prepare(`UPDATE tasks SET status='pending_confirmation', updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
  const result = db.prepare(`INSERT INTO messages (task_id, sender_id, type, video_url, content) VALUES (?,?,'video',?,'Відео-підтвердження виконання')`).run(task.id, req.user.id, videoUrl);
  const message = db.prepare(`SELECT m.*, u.nickname as sender_nickname FROM messages m LEFT JOIN users u ON m.sender_id=u.id WHERE m.id=?`).get(result.lastInsertRowid);
  sendToUser(task.creator_id, { type: 'new_message', message, taskId: task.id });
  sendToUser(task.creator_id, { type: 'task_update', taskId: task.id, status: 'pending_confirmation' });
  createNotification(task.creator_id, '🎥 Відео-підтвердження завантажено', `Виконавець завантажив відео по "${task.title}". Перевірте та підтвердіть.`, 'task', task.id);
  res.status(201).json({ message, videoUrl });
});

module.exports = router;
