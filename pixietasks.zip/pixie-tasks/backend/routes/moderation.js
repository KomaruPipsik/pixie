const express = require('express');
const router = express.Router();
const { getDb } = require('../models/db');
const { authMiddleware, requireRole } = require('../middleware/auth');
const { createNotification } = require('../models/notification');
const { refundFunds, releaseFunds } = require('../models/payment');
const { assignModerator } = require('./tasks');
const isMod = requireRole('moderator', 'owner');

router.get('/queue', authMiddleware, isMod, (req, res) => {
  const db = getDb();
  const tasks = db.prepare(`
    SELECT t.*, c.nickname as creator_nickname FROM tasks t JOIN users c ON t.creator_id = c.id
    WHERE t.moderator_id = ? AND t.status = 'on_moderation' ORDER BY t.created_at ASC
  `).all(req.user.id);
  res.json({ tasks });
});

router.get('/pending', authMiddleware, isMod, (req, res) => {
  const db = getDb();
  const tasks = db.prepare(`SELECT t.*, c.nickname as creator_nickname FROM tasks t JOIN users c ON t.creator_id = c.id WHERE t.status='pending_moderation' ORDER BY t.created_at ASC`).all();
  res.json({ tasks });
});

router.post('/:id/approve', authMiddleware, isMod, (req, res) => {
  const { comment } = req.body;
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Не знайдено' });
  if (task.moderator_id !== req.user.id) return res.status(403).json({ error: 'Це завдання не призначено вам' });
  if (task.status !== 'on_moderation') return res.status(400).json({ error: 'Завдання не на модерації' });
  db.prepare(`UPDATE tasks SET status='approved_awaiting_payment', moderator_comment=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(comment || null, task.id);
  createNotification(task.creator_id, '✅ Завдання схвалено!',
    `Ваше завдання "${task.title}" пройшло модерацію${comment ? `: ${comment}` : ''}. Внесіть передоплату для публікації.`, 'task', task.id);
  res.json({ message: 'Схвалено' });
});

router.post('/:id/reject', authMiddleware, isMod, (req, res) => {
  const { comment } = req.body;
  if (!comment || comment.trim().length < 5) return res.status(400).json({ error: 'Вкажіть причину відхилення (мінімум 5 символів)' });
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Не знайдено' });
  if (task.moderator_id !== req.user.id) return res.status(403).json({ error: 'Це завдання не призначено вам' });
  db.prepare(`UPDATE tasks SET status='rejected', moderator_comment=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(comment.trim(), task.id);
  createNotification(task.creator_id, '❌ Завдання відхилено',
    `Ваше завдання "${task.title}" відхилено. Причина: ${comment.trim()}`, 'task', task.id);
  res.json({ message: 'Відхилено' });
});

router.post('/:id/pass', authMiddleware, isMod, (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Не знайдено' });
  if (task.moderator_id !== req.user.id) return res.status(403).json({ error: 'Не ваше завдання' });
  const nextMod = db.prepare(`
    SELECT u.id FROM users u WHERE u.role IN ('moderator','owner') AND u.id != ?
    AND u.id NOT IN (SELECT COALESCE(moderator_id,0) FROM tasks WHERE status='on_moderation' AND moderator_id IS NOT NULL)
    LIMIT 1
  `).get(req.user.id);
  if (nextMod) {
    db.prepare(`UPDATE tasks SET moderator_id=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(nextMod.id, task.id);
    createNotification(nextMod.id, '📋 Завдання передано вам', `Завдання "${task.title}" передано вам іншим модератором.`, 'task', task.id);
  } else {
    db.prepare(`UPDATE tasks SET status='pending_moderation', moderator_id=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
  }
  res.json({ message: 'Передано' });
});

router.get('/disputes', authMiddleware, isMod, (req, res) => {
  const db = getDb();
  const disputes = db.prepare(`
    SELECT t.*, c.nickname as creator_nickname, e.nickname as executor_nickname
    FROM tasks t JOIN users c ON t.creator_id=c.id LEFT JOIN users e ON t.executor_id=e.id
    WHERE t.status='disputed' ORDER BY t.dispute_expires_at ASC
  `).all();
  res.json({ disputes });
});

router.post('/disputes/:id/resolve', authMiddleware, isMod, (req, res) => {
  const { winner } = req.body;
  if (!['executor','creator'].includes(winner)) return res.status(400).json({ error: 'winner: executor або creator' });
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
  if (!task || task.status !== 'disputed') return res.status(400).json({ error: 'Спір не активний' });
  if (winner === 'executor') {
    const executor = db.prepare('SELECT * FROM users WHERE id = ?').get(task.executor_id);
    const owner = db.prepare("SELECT * FROM users WHERE role='owner'").get();
    const pay = releaseFunds(task.id, task.executor_id, owner.id, task.held_amount, executor.card_number, owner.card_number);
    db.prepare(`UPDATE tasks SET status='completed', updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
    createNotification(task.executor_id, '⚖️ Спір вирішено на вашу користь!', `Модератор вирішив спір по "${task.title}" на вашу користь. Нараховано ${pay.executorAmount} грн.`, 'payment', task.id);
    createNotification(task.creator_id, '⚖️ Спір вирішено не на вашу користь', `Модератор вирішив спір по "${task.title}" на користь виконавця.`, 'dispute', task.id);
  } else {
    const creator = db.prepare('SELECT * FROM users WHERE id = ?').get(task.creator_id);
    refundFunds(task.id, task.creator_id, task.held_amount, creator.card_number);
    db.prepare(`UPDATE tasks SET status='rejected', held_amount=0, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
    createNotification(task.creator_id, '⚖️ Спір вирішено на вашу користь!', `Модератор вирішив спір по "${task.title}" на вашу користь. Кошти повернуто.`, 'payment', task.id);
    createNotification(task.executor_id, '⚖️ Спір вирішено не на вашу користь', `Модератор вирішив спір по "${task.title}" на користь замовника.`, 'dispute', task.id);
  }
  res.json({ message: `Спір вирішено на користь ${winner === 'executor' ? 'виконавця' : 'замовника'}` });
});

module.exports = router;
