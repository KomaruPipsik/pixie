const cron = require('node-cron');
const { getDb } = require('../models/db');
const { refundFunds } = require('../models/payment');
const { createNotification } = require('../models/notification');
const { assignModerator } = require('../routes/tasks');

function startCronJobs() {
  cron.schedule('* * * * *', () => {
    const db = getDb();
    if (!db) return;
    const now = new Date().toISOString();

    // 1. Expire active tasks (48h nobody took)
    db.prepare(`SELECT * FROM tasks WHERE status='active' AND timer_expires_at IS NOT NULL AND timer_expires_at < ?`).all(now)
      .forEach(task => {
        console.log(`[CRON] Task #${task.id} expired`);
        const creator = db.prepare('SELECT * FROM users WHERE id = ?').get(task.creator_id);
        if (task.held_amount > 0 && creator?.card_number) refundFunds(task.id, task.creator_id, task.held_amount, creator.card_number);
        db.prepare(`UPDATE tasks SET status='expired', held_amount=0, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
        createNotification(task.creator_id, '⏰ Завдання не знайшло виконавця',
          `Завдання "${task.title}" закінчилось — ніхто не взявся за 48 годин. Кошти повернуто.`, 'payment', task.id);
      });

    // 2. Auto-close disputes after 48h → refund creator
    db.prepare(`SELECT * FROM tasks WHERE status='disputed' AND dispute_expires_at IS NOT NULL AND dispute_expires_at < ?`).all(now)
      .forEach(task => {
        console.log(`[CRON] Dispute #${task.id} auto-closed → creator`);
        const creator = db.prepare('SELECT * FROM users WHERE id = ?').get(task.creator_id);
        if (task.held_amount > 0 && creator?.card_number) refundFunds(task.id, task.creator_id, task.held_amount, creator.card_number);
        db.prepare(`UPDATE tasks SET status='rejected', held_amount=0, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
        createNotification(task.creator_id, '⚖️ Спір закрито автоматично',
          `Спір по "${task.title}" закрито на вашу користь — модератори не встигли розглянути за 48 годин. Кошти повернуто.`, 'payment', task.id);
        if (task.executor_id) createNotification(task.executor_id, '⚖️ Спір закрито автоматично',
          `Спір по "${task.title}" закрито на користь замовника (48 годин без рішення).`, 'dispute', task.id);
      });

    // 3. Expire appeal windows (24h)
    db.prepare(`SELECT * FROM tasks WHERE status='in_progress' AND appeal_expires_at IS NOT NULL AND appeal_expires_at < ?`).all(now)
      .forEach(task => {
        console.log(`[CRON] Appeal window #${task.id} expired → refund creator`);
        const creator = db.prepare('SELECT * FROM users WHERE id = ?').get(task.creator_id);
        if (task.held_amount > 0 && creator?.card_number) refundFunds(task.id, task.creator_id, task.held_amount, creator.card_number);
        db.prepare(`UPDATE tasks SET status='rejected', held_amount=0, appeal_expires_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(task.id);
        createNotification(task.creator_id, '💰 Кошти повернуто',
          `Виконавець не подав апеляцію по "${task.title}" вчасно. Кошти повернуто на вашу карту.`, 'payment', task.id);
        if (task.executor_id) createNotification(task.executor_id, '⏰ Час апеляції вийшов',
          `Ви не встигли подати апеляцію по "${task.title}" протягом 24 годин.`, 'task', task.id);
      });

    // 4. Assign pending tasks to free moderators
    db.prepare(`SELECT id FROM tasks WHERE status='pending_moderation' LIMIT 5`).all()
      .forEach(t => assignModerator(t.id));
  });

  console.log('[CRON] Background jobs started (interval: 1 min)');
}

module.exports = { startCronJobs };
