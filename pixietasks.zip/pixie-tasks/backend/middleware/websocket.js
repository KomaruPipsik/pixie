const WebSocket = require('ws');
const jwt = require('jsonwebtoken');

let wss = null;
// Map userId -> Set of WebSocket connections
const userConnections = new Map();

function initWebSocket(server) {
  wss = new WebSocket.Server({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    // Extract token from query string
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');

    if (!token) {
      ws.close(1008, 'Token required');
      return;
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const userId = decoded.userId;
      ws.userId = userId;

      if (!userConnections.has(userId)) {
        userConnections.set(userId, new Set());
      }
      userConnections.get(userId).add(ws);

      ws.send(JSON.stringify({ type: 'connected', message: 'WebSocket подключен' }));

      ws.on('close', () => {
        const conns = userConnections.get(userId);
        if (conns) {
          conns.delete(ws);
          if (conns.size === 0) userConnections.delete(userId);
        }
      });

      ws.on('error', (err) => {
        console.error('[WS] Error:', err.message);
      });
    } catch (err) {
      ws.close(1008, 'Invalid token');
    }
  });

  console.log('[WS] WebSocket server initialized');
}

function sendToUser(userId, data) {
  const conns = userConnections.get(userId);
  if (!conns) return;
  const payload = JSON.stringify(data);
  conns.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  });
}

function broadcast(data) {
  if (!wss) return;
  const payload = JSON.stringify(data);
  wss.clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  });
}

module.exports = { initWebSocket, sendToUser, broadcast };
