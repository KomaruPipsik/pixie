const jwt = require('jsonwebtoken');
const { getDb } = require('../models/db');

function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(401).json({ error: 'Токен не надано' });
  const token = authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Невірний формат токена' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(decoded.userId);
    if (!user) return res.status(401).json({ error: 'Користувача не знайдено' });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: 'Токен недійсний або прострочений' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Недостатньо прав' });
    next();
  };
}

module.exports = { authMiddleware, requireRole };
