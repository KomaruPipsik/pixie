const { getDb } = require('./db');
const { sendToUser } = require('../middleware/websocket');

function createNotification(userId, title, body, type = 'system', taskId = null) {
  try {
    const db = getDb();
    const result = db.prepare(`
      INSERT INTO notifications (user_id, title, body, type, task_id)
      VALUES (?, ?, ?, ?, ?)
    `).run(userId, title, body, type, taskId);

    const notification = {
      id: result.lastInsertRowid,
      userId, title, body, type, taskId,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    sendToUser(userId, { type: 'notification', notification });
    return notification;
  } catch (err) {
    console.error('[NOTIFY] Error:', err.message);
  }
}

module.exports = { createNotification };
