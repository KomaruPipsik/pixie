const { v4: uuidv4 } = require('uuid');
const { getDb } = require('./db');

const COMMISSION_RATE = parseFloat(process.env.COMMISSION_RATE) || 0.20;

function maskCard(c) { return c ? '**** **** **** ' + String(c).slice(-4) : '****'; }

function holdFunds(taskId, payerId, amount, cardNumber) {
  console.log(`[PAY] Hold ${amount} UAH from ${maskCard(cardNumber)} task#${taskId}`);
  const db = getDb();
  const txId = uuidv4();
  db.prepare(`INSERT INTO payments (task_id, payer_id, amount, type, status, mock_transaction_id) VALUES (?,?,?,'hold','completed',?)`)
    .run(taskId, payerId, amount, txId);
  return { success: true, transactionId: txId };
}

function releaseFunds(taskId, payeeId, ownerId, amount, executorCard, ownerCard) {
  const db = getDb();
  const commission = Math.round(amount * COMMISSION_RATE * 100) / 100;
  const executorAmount = Math.round((amount - commission) * 100) / 100;
  console.log(`[PAY] Release task#${taskId}: executor=${executorAmount}, commission=${commission}`);
  db.prepare(`INSERT INTO payments (task_id, payee_id, amount, type, status, mock_transaction_id) VALUES (?,?,?,'release','completed',?)`)
    .run(taskId, payeeId, executorAmount, uuidv4());
  db.prepare(`INSERT INTO payments (task_id, payee_id, amount, type, status, mock_transaction_id) VALUES (?,?,?,'commission','completed',?)`)
    .run(taskId, ownerId, commission, uuidv4());
  return { success: true, executorAmount, commission };
}

function refundFunds(taskId, payerId, amount, cardNumber) {
  const db = getDb();
  console.log(`[PAY] Refund ${amount} UAH to ${maskCard(cardNumber)} task#${taskId}`);
  db.prepare(`INSERT INTO payments (task_id, payer_id, amount, type, status, mock_transaction_id) VALUES (?,?,?,'refund','completed',?)`)
    .run(taskId, payerId, amount, uuidv4());
  return { success: true };
}

module.exports = { holdFunds, releaseFunds, refundFunds };
