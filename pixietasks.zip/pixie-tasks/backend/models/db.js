const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const DB_PATH = path.resolve(process.env.DB_PATH || './database.bin');

let db = null;

// Synchronous wrapper around sql.js so the rest of the codebase uses .prepare/.run/.get/.all
class SyncDB {
  constructor(sqlDb) {
    this._db = sqlDb;
    this._dirty = false;
    // Persist every 2 seconds if dirty
    setInterval(() => this._flush(), 2000);
  }

  _flush() {
    if (!this._dirty) return;
    try {
      const data = this._db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
      this._dirty = false;
    } catch (e) { console.error('[DB] flush error:', e.message); }
  }

  exec(sql) {
    this._db.run(sql);
    this._dirty = true;
  }

  pragma(stmt) {
    try { this._db.run(`PRAGMA ${stmt}`); } catch {}
  }

  prepare(sql) {
    const self = this;
    return {
      run: (...params) => {
        const flat = params.flat();
        self._db.run(sql, flat);
        self._dirty = true;
        // Get last insert rowid
        const row = self._db.exec('SELECT last_insert_rowid() as id');
        const lastInsertRowid = row[0]?.values[0]?.[0] ?? 0;
        return { lastInsertRowid, changes: 1 };
      },
      get: (...params) => {
        const flat = params.flat();
        const result = self._db.exec(sql, flat);
        if (!result[0]) return undefined;
        const cols = result[0].columns;
        const row = result[0].values[0];
        if (!row) return undefined;
        const obj = {};
        cols.forEach((c, i) => obj[c] = row[i]);
        return obj;
      },
      all: (...params) => {
        const flat = params.flat();
        const result = self._db.exec(sql, flat);
        if (!result[0]) return [];
        const cols = result[0].columns;
        return result[0].values.map(row => {
          const obj = {};
          cols.forEach((c, i) => obj[c] = row[i]);
          return obj;
        });
      }
    };
  }
}

async function initializeDatabase() {
  const SQL = await initSqlJs();
  let sqlDb;

  if (fs.existsSync(DB_PATH)) {
    const data = fs.readFileSync(DB_PATH);
    sqlDb = new SQL.Database(data);
    console.log('[DB] Loaded existing database from', DB_PATH);
  } else {
    sqlDb = new SQL.Database();
    console.log('[DB] Created new database at', DB_PATH);
  }

  db = new SyncDB(sqlDb);

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nickname TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      city TEXT,
      school TEXT,
      card_number TEXT,
      balance REAL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      creator_id INTEGER NOT NULL,
      executor_id INTEGER,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      city TEXT NOT NULL,
      school TEXT NOT NULL,
      amount REAL NOT NULL,
      status TEXT DEFAULT 'pending_moderation',
      moderator_id INTEGER,
      moderator_comment TEXT,
      held_amount REAL DEFAULT 0,
      timer_expires_at DATETIME,
      dispute_expires_at DATETIME,
      appeal_expires_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_id INTEGER NOT NULL,
      sender_id INTEGER,
      content TEXT,
      video_url TEXT,
      type TEXT DEFAULT 'text',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      type TEXT DEFAULT 'system',
      task_id INTEGER,
      is_read INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_id INTEGER,
      payer_id INTEGER,
      payee_id INTEGER,
      amount REAL NOT NULL,
      type TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      mock_transaction_id TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Seed owner
  const ownerNick = process.env.OWNER_NICKNAME || 'Pixie';
  const existingOwner = db.prepare('SELECT id FROM users WHERE nickname = ?').get(ownerNick);
  if (!existingOwner) {
    const hash = bcrypt.hashSync('pixie_admin_2024', 10);
    db.prepare(`INSERT INTO users (nickname, password_hash, role, card_number) VALUES (?, ?, 'owner', ?)`)
      .run(ownerNick, hash, process.env.OWNER_CARD || '4441111122223333');
    console.log(`[DB] Owner "${ownerNick}" created`);
  }

  // Seed moderator
  const existingMod = db.prepare('SELECT id FROM users WHERE nickname = ?').get('Kuga');
  if (!existingMod) {
    const hash = bcrypt.hashSync('kuga_mod_2024', 10);
    db.prepare(`INSERT INTO users (nickname, password_hash, role) VALUES ('Kuga', ?, 'moderator')`).run(hash);
    console.log('[DB] Moderator "Kuga" created');
  }

  // Flush initial state
  db._dirty = true;
  db._flush();
  console.log('[DB] Database ready');
}

function getDb() { return db; }

module.exports = { initializeDatabase, getDb };
