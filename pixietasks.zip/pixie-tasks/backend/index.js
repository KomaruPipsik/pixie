require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const path = require('path');
const fs = require('fs');

const { initializeDatabase } = require('./models/db');
const { initWebSocket } = require('./middleware/websocket');
const { startCronJobs } = require('./jobs/cron');

const app = express();
const server = http.createServer(app);

app.use(cors({
  origin: ['http://localhost:5173','http://localhost:3000','http://127.0.0.1:5173'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.use('/uploads', express.static(UPLOAD_DIR));

// Serve built frontend from public/
const publicDir = path.join(__dirname, 'public');
if (fs.existsSync(publicDir)) {
  app.use(express.static(publicDir));
}

// API routes (mounted after DB init)
function mountRoutes() {
  app.use('/api/auth',          require('./routes/auth'));
  app.use('/api/profile',       require('./routes/profile'));
  app.use('/api/tasks',         require('./routes/tasks'));
  app.use('/api/moderation',    require('./routes/moderation'));
  app.use('/api/messages',      require('./routes/messages'));
  app.use('/api/notifications', require('./routes/notifications'));
  app.use('/api/admin',         require('./routes/admin'));

  app.get('/api/health', (req, res) => res.json({ status: 'ok', ts: new Date().toISOString() }));

  // SPA fallback — must be AFTER api routes
  if (fs.existsSync(publicDir)) {
    app.get('*', (req, res) => {
      res.sendFile(path.join(publicDir, 'index.html'));
    });
  }

  // Error handler
  app.use((err, req, res, next) => {
    console.error('[ERR]', err.message);
    res.status(500).json({ error: err.message || 'Внутрішня помилка сервера' });
  });
}

const PORT = process.env.PORT || 3001;

initializeDatabase().then(() => {
  mountRoutes();
  initWebSocket(server);
  startCronJobs();
  server.listen(PORT, () => {
    console.log(`\n✅ PixieTasks запущено  →  http://localhost:${PORT}`);
    console.log(`📡 API                   →  http://localhost:${PORT}/api`);
    console.log(`🔌 WebSocket             →  ws://localhost:${PORT}/ws`);
    console.log('\n👤 Тестові акаунти:');
    console.log('   Власник:    Pixie  / pixie_admin_2024');
    console.log('   Модератор:  Kuga   / kuga_mod_2024\n');
  });
}).catch(err => {
  console.error('[FATAL] Помилка ініціалізації БД:', err);
  process.exit(1);
});
