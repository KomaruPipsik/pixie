import { useState, useEffect } from 'react';
import { getTimeLeft } from '../utils/helpers';

export function useCountdown(expiresAt) {
  const [timeLeft, setTimeLeft] = useState(() => getTimeLeft(expiresAt));

  useEffect(() => {
    if (!expiresAt) { setTimeLeft(null); return; }
    const timer = setInterval(() => {
      setTimeLeft(getTimeLeft(expiresAt));
    }, 1000);
    return () => clearInterval(timer);
  }, [expiresAt]);

  return timeLeft;
}
