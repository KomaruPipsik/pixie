import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import useStore from '../store/useStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const [form, setForm] = useState({ nickname: '', password: '', confirm: '' });
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const { setUser, setToken, connectWS } = useStore();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.nickname.trim() || !form.password) return toast.error('Заповніть всі поля');
    if (form.password !== form.confirm) return toast.error('Паролі не збігаються');
    if (form.password.length < 6) return toast.error('Пароль мінімум 6 символів');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/register', { nickname: form.nickname.trim(), password: form.password });
      setToken(data.token);
      setUser(data.user);
      connectWS();
      toast.success('Акаунт створено!');
      navigate('/profile');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Помилка реєстрації');
    } finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{background:'#09090b'}}>
      <div className="w-full max-w-sm animate-slide-up">
        <div className="text-center mb-8">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 items-center justify-center text-2xl mb-4">⚡</div>
          <h1 className="font-display font-bold text-2xl text-zinc-100">Реєстрація</h1>
          <p className="text-zinc-500 text-sm mt-1">Приєднуйтесь до PixieTasks</p>
        </div>

        <div className="card !p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Нікнейм</label>
              <input className="input-field" placeholder="cool_nickname" value={form.nickname}
                onChange={e => setForm(p => ({...p, nickname: e.target.value}))} />
              <p className="text-xs text-zinc-600 mt-1">3–30 символів</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Пароль</label>
              <div className="relative">
                <input className="input-field !pr-10" type={showPwd ? 'text' : 'password'}
                  placeholder="мінімум 6 символів" value={form.password}
                  onChange={e => setForm(p => ({...p, password: e.target.value}))} />
                <button type="button" onClick={() => setShowPwd(v=>!v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400 transition-colors">
                  {showPwd ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Підтвердити пароль</label>
              <input className="input-field" type="password" placeholder="повторіть пароль" value={form.confirm}
                onChange={e => setForm(p => ({...p, confirm: e.target.value}))} />
            </div>
            <button type="submit" disabled={loading} className="btn-accent w-full justify-center !py-3 mt-2">
              {loading ? <div className="w-4 h-4 border-2 border-zinc-500 border-t-zinc-900 rounded-full animate-spin mx-auto" /> : 'Створити акаунт'}
            </button>
          </form>
          <p className="text-center text-zinc-600 text-sm mt-4">
            Вже маєте акаунт?{' '}
            <Link to="/login" className="text-zinc-300 hover:text-white underline underline-offset-2 transition-colors">Увійти</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
