import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, RefreshCw, ClipboardList } from 'lucide-react';
import api from '../utils/api';
import useStore from '../store/useStore';
import TaskCard from '../components/TaskCard';
import toast from 'react-hot-toast';

const TABS = [
  { key: 'all',       label: 'Всі' },
  { key: 'created',   label: 'Створені мною' },
  { key: 'executing', label: 'Виконую' },
];

export default function MyTasksPage() {
  const { user } = useStore();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('all');

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    try {
      const { data } = await api.get('/tasks/my');
      setTasks(data.tasks);
    } catch { toast.error('Помилка завантаження'); } finally { setLoading(false); }
  }

  const filtered = tasks.filter((t) => {
    if (tab === 'created')   return t.creator_id === user.id;
    if (tab === 'executing') return t.executor_id === user.id;
    return true;
  });

  const activeCount = tasks.filter(
    (t) => t.creator_id === user.id && !['completed','rejected','expired'].includes(t.status)
  ).length;

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="section-title">Мої завдання</h1>
          <p className="section-sub">
            {activeCount}/5 активних · {tasks.length} всього
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="btn-ghost !px-3" title="Оновити">
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          </button>
          <button onClick={() => navigate('/tasks/create')} className="btn-accent flex items-center gap-1.5 text-sm">
            <Plus size={14} /> Нове
          </button>
        </div>
      </div>

      {/* Active slots progress */}
      <div className="card !p-4 mb-5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-zinc-500">Активні слоти</span>
          <span className={`text-xs font-mono font-bold ${activeCount >= 5 ? 'text-red-400' : 'text-zinc-300'}`}>
            {activeCount} / 5
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-zinc-800 overflow-hidden">
          <div className="h-full rounded-full transition-all duration-700 ease-out"
            style={{
              width: `${(activeCount / 5) * 100}%`,
              background: activeCount >= 5 ? '#ef4444' : activeCount >= 3 ? '#f59e0b' : '#71717a'
            }} />
        </div>
        {activeCount >= 5 && (
          <p className="text-xs text-red-500 mt-2">Ліміт досягнуто. Завершіть або дочекайтесь завершення завдань.</p>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 p-1 rounded-xl bg-zinc-900 border border-zinc-800 w-fit">
        {TABS.map((t) => {
          const cnt = t.key === 'created'   ? tasks.filter(x => x.creator_id === user.id).length
                    : t.key === 'executing' ? tasks.filter(x => x.executor_id === user.id).length
                    : tasks.length;
          return (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                tab === t.key ? 'bg-zinc-700 text-zinc-100 shadow-sm' : 'text-zinc-500 hover:text-zinc-300'
              }`}>
              {t.label}
              {cnt > 0 && (
                <span className={`text-xs font-mono px-1.5 py-0.5 rounded-md ${
                  tab === t.key ? 'bg-zinc-600 text-zinc-200' : 'bg-zinc-800 text-zinc-600'
                }`}>{cnt}</span>
              )}
            </button>
          );
        })}
      </div>

      {/* Task list */}
      {loading ? (
        <div className="space-y-3">
          {[1,2,3].map((i) => <div key={i} className="h-36 rounded-2xl shimmer-bg" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4">
            <ClipboardList size={22} className="text-zinc-600" />
          </div>
          <p className="text-zinc-400 font-display font-semibold">Завдань немає</p>
          <p className="text-zinc-600 text-sm mt-1">
            {tab === 'all' ? 'Ви ще не створювали та не виконували завдань' :
             tab === 'created' ? 'Ви ще не створювали завдань' : 'Ви ще не виконували завдань'}
          </p>
          {tab !== 'executing' && (
            <button onClick={() => navigate('/tasks/create')} className="btn-ghost mt-4 text-sm mx-auto">
              Створити перше завдання
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((t) => <TaskCard key={t.id} task={t} showStatus />)}
        </div>
      )}
    </div>
  );
}
