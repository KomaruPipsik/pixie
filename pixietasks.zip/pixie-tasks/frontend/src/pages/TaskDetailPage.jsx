import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, School, User2, Clock, CreditCard, CheckCircle2, XCircle, AlertTriangle, MessageSquare, Hash } from 'lucide-react';
import api from '../utils/api';
import useStore from '../store/useStore';
import { TASK_STATUS, formatAmount, formatDateFull } from '../utils/helpers';
import { useCountdown } from '../hooks/useCountdown';
import toast from 'react-hot-toast';

function TimerBlock({ label, expiresAt, color = 'zinc' }) {
  const timer = useCountdown(expiresAt);
  if (!timer) return null;
  const urgent = timer.urgent;
  return (
    <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-sm font-mono transition-colors ${
      urgent
        ? 'bg-red-950/30 border-red-900/40 text-red-400'
        : 'bg-zinc-900 border-zinc-800 text-zinc-400'
    }`}>
      <Clock size={14} className={urgent ? 'animate-pulse' : ''} />
      <span className={urgent ? 'text-red-600' : 'text-zinc-600'}>{label}:</span>
      <span className={`font-bold tabular-nums tracking-wider text-base ${urgent ? 'animate-timer-urgent' : 'text-zinc-200'}`}>
        {timer.expired ? 'час вийшов' : timer.display}
      </span>
    </div>
  );
}

export default function TaskDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, setActiveChatTaskId } = useStore();
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState('');

  useEffect(() => { loadTask(); }, [id]);
  useEffect(() => {
    const handler = (e) => { if (e.detail?.taskId === parseInt(id)) loadTask(); };
    window.addEventListener('task_update', handler);
    return () => window.removeEventListener('task_update', handler);
  }, [id]);

  async function loadTask() {
    try {
      const { data } = await api.get(`/tasks/${id}`);
      setTask(data.task);
    } catch {
      toast.error('Завдання не знайдено');
      navigate('/');
    } finally { setLoading(false); }
  }

  async function doAction(endpoint, successMsg, extra = {}) {
    setActionLoading(endpoint);
    try {
      await api.post(`/tasks/${id}/${endpoint}`, extra);
      toast.success(successMsg);
      await loadTask();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Помилка');
    } finally { setActionLoading(''); }
  }

  function Loader({ name }) {
    return actionLoading === name
      ? <div className="w-4 h-4 border border-current border-t-transparent rounded-full animate-spin" />
      : null;
  }

  if (loading) return (
    <div className="max-w-2xl mx-auto space-y-4 animate-fade-in pt-4">
      <div className="h-6 w-24 rounded-lg shimmer-bg" />
      <div className="h-72 rounded-2xl shimmer-bg" />
      <div className="h-32 rounded-2xl shimmer-bg" />
    </div>
  );
  if (!task) return null;

  const isCreator  = task.creator_id === user.id;
  const isExecutor = task.executor_id === user.id;
  const isMyTask   = isCreator || isExecutor;
  const isMod      = ['moderator','owner'].includes(user.role);
  const statusInfo = TASK_STATUS[task.status] || { label: task.status, color: 'bg-zinc-800 text-zinc-400 border-zinc-700' };
  const executorGets = parseFloat(task.amount) * 0.80;
  const canChat = isMyTask && ['in_progress','pending_confirmation','disputed'].includes(task.status);

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <button onClick={() => navigate(-1)}
        className="flex items-center gap-1.5 text-zinc-600 hover:text-zinc-300 transition-colors mb-5 text-sm">
        <ArrowLeft size={14} /> Назад
      </button>

      {/* ── Main info card ─────────────────────── */}
      <div className="card !p-6 mb-4">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1 min-w-0">
            <span className={`status-badge ${statusInfo.color} mb-3 inline-block`}>{statusInfo.label}</span>
            <h1 className="font-display font-bold text-xl text-zinc-100 leading-snug">{task.title}</h1>
          </div>
          <div className="text-right shrink-0">
            <div className="font-display font-bold text-3xl text-zinc-100 tabular-nums">{formatAmount(task.amount)}</div>
            <div className="text-xs text-zinc-600 mt-1">виконавець отримає</div>
            <div className="text-sm text-zinc-400 font-semibold">{formatAmount(executorGets)}</div>
          </div>
        </div>

        {/* Meta row */}
        <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm text-zinc-500 pb-4 border-b border-zinc-800/60 mb-4">
          <div className="flex items-center gap-1.5"><MapPin size={13} className="text-zinc-600" />{task.city}</div>
          <div className="flex items-center gap-1.5"><School size={13} className="text-zinc-600" />{task.school}</div>
          <div className="flex items-center gap-1.5"><User2 size={13} className="text-zinc-600" />{task.creator_nickname}</div>
          <div className="flex items-center gap-1.5 text-zinc-700 text-xs font-mono">
            <Hash size={11} />{task.id} · {formatDateFull(task.created_at)}
          </div>
        </div>

        {/* Description */}
        <p className="text-zinc-300 text-sm leading-relaxed whitespace-pre-wrap">{task.description}</p>

        {/* Moderator comment */}
        {task.moderator_comment && (
          <div className="mt-4 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-sm">
            <p className="text-xs text-zinc-600 mb-1 font-medium">Коментар модератора ({task.moderator_nickname})</p>
            <p className="text-zinc-400">{task.moderator_comment}</p>
          </div>
        )}

        {/* Executor info */}
        {task.executor_nickname && (
          <div className="mt-4 flex items-center gap-2 text-sm text-zinc-500">
            <div className="w-2 h-2 rounded-full bg-violet-500 animate-pulse" />
            Виконавець: <span className="text-zinc-300 font-mono">{task.executor_nickname}</span>
          </div>
        )}
      </div>

      {/* ── Timers ─────────────────────────────── */}
      {task.status === 'active' && task.timer_expires_at && (
        <div className="mb-4">
          <TimerBlock label="До закінчення публікації" expiresAt={task.timer_expires_at} />
        </div>
      )}
      {task.status === 'in_progress' && task.appeal_expires_at && (
        <div className="mb-4">
          <TimerBlock label="Час на апеляцію" expiresAt={task.appeal_expires_at} />
        </div>
      )}
      {task.status === 'disputed' && task.dispute_expires_at && (
        <div className="mb-4">
          <TimerBlock label="Авто-закриття спору" expiresAt={task.dispute_expires_at} />
        </div>
      )}

      {/* ── Actions card ───────────────────────── */}
      <div className="card !p-5 space-y-3">

        {/* 1. Creator pays upfront */}
        {isCreator && task.status === 'approved_awaiting_payment' && (
          <div>
            <div className="flex items-start gap-2 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-400 mb-3">
              <CreditCard size={15} className="text-zinc-500 mt-0.5 shrink-0" />
              <div>
                Ваше завдання схвалено! Для публікації внесіть передоплату{' '}
                <strong className="text-zinc-200">{formatAmount(task.amount)}</strong>. Кошти будуть заморожені до завершення.
              </div>
            </div>
            <button onClick={() => doAction('pay','Оплата успішна! Завдання опубліковано.')}
              disabled={!!actionLoading}
              className="btn-success flex items-center gap-2 disabled:opacity-40">
              <Loader name="pay" /><CreditCard size={14} /> Оплатити {formatAmount(task.amount)}
            </button>
          </div>
        )}

        {/* 2. Executor takes task */}
        {!isMyTask && !isMod && task.status === 'active' && (
          <div>
            <div className="grid grid-cols-2 gap-2 text-xs mb-3">
              <div className="px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-500">
                <p className="text-zinc-600 mb-0.5">Ви отримаєте</p>
                <p className="text-zinc-200 font-semibold text-sm">{formatAmount(executorGets)}</p>
              </div>
              <div className="px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-500">
                <p className="text-zinc-600 mb-0.5">Потрібно</p>
                <p className="text-zinc-400">📹 відео + 💳 карта</p>
              </div>
            </div>
            <button onClick={() => doAction('take','Завдання взято в роботу! Відкрийте чат.')}
              disabled={!!actionLoading}
              className="btn-accent flex items-center gap-2 disabled:opacity-40">
              <Loader name="take" /> 🚀 Взяти в роботу
            </button>
          </div>
        )}

        {/* 3. Creator: confirm or reject video */}
        {isCreator && task.status === 'pending_confirmation' && (
          <div>
            <div className="px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-400 mb-3">
              🎥 Виконавець завантажив відео-підтвердження. Перегляньте чат і підтвердіть або відхиліть виконання.
            </div>
            <div className="flex gap-2 flex-wrap">
              <button onClick={() => doAction('confirm','✅ Завдання підтверджено! Оплата відправлена.')}
                disabled={!!actionLoading} className="btn-success flex items-center gap-2 disabled:opacity-40">
                <Loader name="confirm" /><CheckCircle2 size={14} /> Підтвердити виконання
              </button>
              <button onClick={() => doAction('reject','❌ Відхилено. Виконавець повідомлений.')}
                disabled={!!actionLoading} className="btn-danger flex items-center gap-2 disabled:opacity-40">
                <Loader name="reject" /><XCircle size={14} /> Відхилити
              </button>
            </div>
          </div>
        )}

        {/* 4. Executor: appeal after rejection */}
        {isExecutor && task.status === 'in_progress' && task.appeal_expires_at && (
          <div>
            <div className="px-4 py-3 rounded-xl bg-amber-950/30 border border-amber-900/40 text-sm text-amber-400 mb-3">
              ⚠️ Замовник відхилив ваше відео. Якщо ви вважаєте, що завдання виконано — подайте апеляцію. Модератори розглянуть і вирішать спір.
            </div>
            <button onClick={() => doAction('appeal','⚖️ Апеляцію подано! Очікуйте рішення модераторів.')}
              disabled={!!actionLoading} className="btn-danger flex items-center gap-2 disabled:opacity-40">
              <Loader name="appeal" /><AlertTriangle size={14} /> Подати апеляцію
            </button>
          </div>
        )}

        {/* 5. Disputed info */}
        {task.status === 'disputed' && (
          <div className="px-4 py-3 rounded-xl bg-red-950/20 border border-red-900/30 text-sm text-zinc-400">
            ⚖️ Спір на розгляді у модераторів. Кошти заморожені до прийняття рішення. Якщо рішення не буде прийнято протягом 48 годин — кошти автоматично повернуться замовнику.
          </div>
        )}

        {/* 6. Chat button */}
        {canChat && (
          <button onClick={() => setActiveChatTaskId(task.id)}
            className="btn-ghost flex items-center gap-2 w-full justify-center">
            <MessageSquare size={14} /> Відкрити чат з {isCreator ? 'виконавцем' : 'замовником'}
          </button>
        )}

        {/* 7. Completed */}
        {task.status === 'completed' && (
          <div className="px-4 py-3 rounded-xl bg-emerald-950/30 border border-emerald-900/30 text-sm text-emerald-400 text-center">
            ✅ Завдання успішно виконано! Виконавець отримав оплату.
          </div>
        )}
      </div>
    </div>
  );
}
