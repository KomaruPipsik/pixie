import { useState, useEffect } from 'react';
import { Search, MapPin, School, SlidersHorizontal, RefreshCw, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import useStore from '../store/useStore';
import TaskCard from '../components/TaskCard';
import { CITIES, getSchools } from '../utils/cities';
import toast from 'react-hot-toast';

export default function HomePage() {
  const { user } = useStore();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterCity, setFilterCity] = useState(user?.city || '');
  const [filterSchool, setFilterSchool] = useState(user?.school || '');
  const [search, setSearch] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const schools = getSchools(filterCity);

  useEffect(() => { loadTasks(); }, [filterCity, filterSchool]);

  useEffect(() => {
    const h = () => loadTasks();
    window.addEventListener('task_update', h);
    return () => window.removeEventListener('task_update', h);
  }, []);

  async function loadTasks() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filterCity)   params.set('city', filterCity);
      if (filterSchool) params.set('school', filterSchool);
      const { data } = await api.get(`/tasks?${params}`);
      setTasks(data.tasks);
    } catch { toast.error('Помилка завантаження'); } finally { setLoading(false); }
  }

  const filtered = tasks.filter((t) =>
    !search ||
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    t.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="mb-6">
        <h1 className="section-title">
          Активні завдання
        </h1>
        <p className="section-sub">Знайди завдання поблизу своєї школи і заробляй</p>
      </div>

      {/* Search + filter bar */}
      <div className="flex gap-2 mb-3">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600 pointer-events-none" />
          <input value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Пошук завдань…" className="input-field !pl-9 !py-2.5 text-sm" />
        </div>
        <button onClick={() => setShowFilters((v) => !v)}
          className={`btn-ghost flex items-center gap-1.5 shrink-0 text-sm ${showFilters ? '!text-zinc-100 !bg-zinc-700 !border-zinc-600' : ''}`}>
          <SlidersHorizontal size={13} />
          <span className="hidden sm:inline">Фільтри</span>
          {(filterCity || filterSchool) && <span className="w-1.5 h-1.5 rounded-full bg-zinc-300" />}
        </button>
        <button onClick={loadTasks} className="btn-ghost !px-3" title="Оновити">
          <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div className="card !p-4 mb-3 animate-slide-down">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-zinc-500 mb-1.5 flex items-center gap-1"><MapPin size={10}/>Місто</label>
              <select value={filterCity}
                onChange={(e) => { setFilterCity(e.target.value); setFilterSchool(''); }}
                className="input-field !py-2 text-sm">
                <option value="">Всі міста</option>
                {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-zinc-500 mb-1.5 flex items-center gap-1"><School size={10}/>Школа</label>
              <select value={filterSchool} onChange={(e) => setFilterSchool(e.target.value)}
                className="input-field !py-2 text-sm" disabled={!filterCity}>
                <option value="">Всі школи</option>
                {schools.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          {(filterCity || filterSchool) && (
            <button onClick={() => { setFilterCity(''); setFilterSchool(''); }}
              className="mt-3 text-xs text-zinc-600 hover:text-zinc-400 transition-colors">
              × Скинути фільтри
            </button>
          )}
        </div>
      )}

      {/* Results */}
      {loading ? (
        <div className="space-y-3">
          {[1,2,3].map((i) => <div key={i} className="h-40 rounded-2xl shimmer-bg" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-24">
          <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4 text-2xl">
            📭
          </div>
          <p className="text-zinc-400 font-display font-semibold text-lg">Завдань не знайдено</p>
          <p className="text-zinc-600 text-sm mt-1">
            {filterCity ? `В ${filterCity} зараз немає активних завдань` : 'Спробуйте змінити фільтри або пошук'}
          </p>
          <button onClick={() => navigate('/tasks/create')} className="btn-ghost mt-4 mx-auto text-sm">
            + Створити завдання
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-zinc-700 font-mono">{filtered.length} завдань</span>
            {filterCity && (
              <span className="text-xs text-zinc-600 flex items-center gap-1">
                <MapPin size={10}/>{filterCity}{filterSchool ? ` · ${filterSchool}` : ''}
              </span>
            )}
          </div>
          {filtered.map((t) => <TaskCard key={t.id} task={t} />)}
        </div>
      )}
    </div>
  );
}
