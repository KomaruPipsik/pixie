import { useState } from 'react';
import { User2, MapPin, School, CreditCard, Save, LogOut, Shield, Crown } from 'lucide-react';
import api from '../utils/api';
import useStore from '../store/useStore';
import { CITIES, getSchools } from '../utils/cities';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

const ROLE_INFO = {
  owner:     { icon: Crown,  label: '👑 Власник',    color: 'text-amber-400' },
  moderator: { icon: Shield, label: '🛡 Модератор',   color: 'text-blue-400' },
  user:      { icon: User2,  label: '👤 Користувач', color: 'text-zinc-400' },
};

export default function ProfilePage() {
  const { user, setUser, logout } = useStore();
  const navigate = useNavigate();
  const [form, setForm] = useState({ city: user?.city || '', school: user?.school || '', card_number: '' });
  const [loading, setLoading] = useState(false);
  const schools = getSchools(form.city);
  const f = (field) => (e) => setForm((p) => ({ ...p, [field]: e.target.value }));

  const role = ROLE_INFO[user?.role] || ROLE_INFO.user;

  function formatCard(raw) {
    return raw.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
  }

  async function handleSave(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = { city: form.city, school: form.school };
      if (form.card_number) {
        payload.card_number = form.card_number.replace(/\s/g, '');
      }
      const { data } = await api.put('/profile', payload);
      setUser(data.user);
      toast.success('Профіль оновлено!');
      setForm((p) => ({ ...p, card_number: '' }));
    } catch (err) {
      toast.error(err.response?.data?.error || 'Помилка збереження');
    } finally { setLoading(false); }
  }

  return (
    <div className="max-w-lg mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="section-title">Профіль</h1>
        <p className="section-sub">Налаштування акаунту і платіжні дані</p>
      </div>

      {/* Avatar / identity card */}
      <div className="card !p-5 mb-4 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0">
          <User2 size={24} className="text-zinc-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-display font-bold text-lg text-zinc-100 truncate">{user?.nickname}</p>
          <p className={`text-xs font-medium ${role.color}`}>{role.label}</p>
        </div>
        {user?.hasCard && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-500 shrink-0">
            <CreditCard size={11} className="text-zinc-600" />
            {user.cardMasked}
          </div>
        )}
      </div>

      {/* Warning: no card */}
      {!user?.hasCard && (
        <div className="mb-4 px-4 py-3 rounded-xl bg-amber-950/30 border border-amber-900/40 text-sm text-amber-400 flex items-start gap-2">
          <CreditCard size={15} className="mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold">Карта не прив'язана</p>
            <p className="text-amber-600 text-xs mt-0.5">Без карти ви не можете брати завдання в роботу та отримувати оплату</p>
          </div>
        </div>
      )}

      {/* Settings form */}
      <div className="card !p-6 mb-4">
        <form onSubmit={handleSave} className="space-y-4">
          <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-3">Локація</p>

          <div>
            <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
              <MapPin size={11} /> Місто
            </label>
            <select className="input-field !py-2.5 text-sm" value={form.city}
              onChange={(e) => setForm((p) => ({ ...p, city: e.target.value, school: '' }))}>
              <option value="">Оберіть місто</option>
              {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
              <School size={11} /> Школа
            </label>
            <select className="input-field !py-2.5 text-sm" value={form.school} onChange={f('school')} disabled={!form.city}>
              <option value="">Оберіть школу</option>
              {schools.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div className="divider" />
          <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Платіжна карта</p>

          {user?.hasCard && (
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-500">
              <CreditCard size={14} className="text-zinc-600" /> Поточна: <span className="font-mono">{user.cardMasked}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-zinc-400 mb-1.5">
              {user?.hasCard ? 'Замінити карту' : 'Номер карти'} *
            </label>
            <input className="input-field font-mono tracking-widest"
              placeholder="0000 0000 0000 0000"
              value={form.card_number}
              onChange={(e) => {
                setForm((p) => ({ ...p, card_number: formatCard(e.target.value) }));
              }}
              maxLength={19} />
            <p className="text-xs text-zinc-700 mt-1">16 цифр, без пробілів (введіть — пробіли додаються автоматично)</p>
          </div>

          <button type="submit" disabled={loading}
            className="btn-accent w-full !py-3 justify-center flex items-center gap-2">
            {loading
              ? <div className="w-4 h-4 border-2 border-zinc-600 border-t-zinc-900 rounded-full animate-spin" />
              : <Save size={14} />}
            Зберегти зміни
          </button>
        </form>
      </div>

      {/* Danger zone */}
      <div className="card !p-4">
        <p className="text-xs font-semibold text-zinc-600 uppercase tracking-wider mb-3">Вихід</p>
        <button onClick={() => { logout(); navigate('/login'); }}
          className="btn-danger flex items-center gap-2 text-sm">
          <LogOut size={14} /> Вийти з акаунту
        </button>
      </div>
    </div>
  );
}
