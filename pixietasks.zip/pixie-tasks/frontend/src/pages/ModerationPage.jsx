import { useState, useEffect } from 'react';
import { Shield, CheckCircle2, XCircle, SkipForward, Eye, EyeOff, Scale, Clock, RefreshCw } from 'lucide-react';
import api from '../utils/api';
import { formatAmount, formatDate } from '../utils/helpers';
import { useCountdown } from '../hooks/useCountdown';
import toast from 'react-hot-toast';

function TaskModCard({ task, onDone }) {
  const [showDesc, setShowDesc] = useState(false);
  const [comment, setComment] = useState('');
  const [busy, setBusy] = useState('');

  async function act(endpoint) {
    if (endpoint === 'reject' && comment.trim().length < 5)
      return toast.error('Введіть причину відхилення (мін. 5 символів)');
    setBusy(endpoint);
    try {
      await api.post(`/moderation/${task.id}/${endpoint}`, { comment: comment.trim() });
      const msgs = { approve: '✅ Схвалено!', reject: '❌ Відхилено', pass: '➡️ Передано іншому модератору' };
      toast.success(msgs[endpoint]);
      onDone();
    } catch (err) { toast.error(err.response?.data?.error || 'Помилка'); } finally { setBusy(''); }
  }

  function BtnLoader({ name }) {
    return busy === name ? <div className="w-3.5 h-3.5 border border-current border-t-transparent rounded-full animate-spin" /> : null;
  }

  return (
    <div className="card animate-slide-up">
      {/* Task header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <h3 className="font-display font-semibold text-zinc-100 text-[15px] leading-snug">{task.title}</h3>
          <div className="flex items-center gap-3 mt-1 text-xs text-zinc-600 font-mono">
            <span>#{task.id}</span>
            <span>{task.creator_nickname}</span>
            <span>{formatDate(task.created_at)}</span>
          </div>
        </div>
        <span className="font-display font-bold text-lg text-zinc-200 shrink-0">{formatAmount(task.amount)}</span>
      </div>

      {/* Location */}
      <div className="flex gap-4 text-xs text-zinc-500 mb-3">
        <span>📍 {task.city}</span>
        <span>🏫 {task.school}</span>
      </div>

      {/* Description toggle */}
      <button onClick={() => setShowDesc((v) => !v)}
        className="flex items-center gap-1.5 text-xs text-zinc-600 hover:text-zinc-300 transition-colors mb-3">
        {showDesc ? <EyeOff size={11} /> : <Eye size={11} />}
        {showDesc ? 'Приховати опис' : 'Показати повний опис'}
      </button>

      {showDesc && (
        <div className="px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-300 leading-relaxed mb-3 animate-slide-down whitespace-pre-wrap">
          {task.description}
        </div>
      )}

      {/* Comment input */}
      <input value={comment} onChange={(e) => setComment(e.target.value)}
        placeholder="Коментар для автора (обов'язковий при відхиленні)…"
        className="input-field text-sm mb-3" />

      {/* Action buttons */}
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => act('approve')} disabled={!!busy}
          className="btn-success flex items-center gap-2 text-sm disabled:opacity-40">
          <BtnLoader name="approve" /><CheckCircle2 size={14} /> Схвалити
        </button>
        <button onClick={() => act('reject')} disabled={!!busy}
          className="btn-danger flex items-center gap-2 text-sm disabled:opacity-40">
          <BtnLoader name="reject" /><XCircle size={14} /> Відхилити
        </button>
        <button onClick={() => act('pass')} disabled={!!busy}
          className="btn-ghost flex items-center gap-2 text-sm disabled:opacity-40">
          <BtnLoader name="pass" /><SkipForward size={14} /> Стоп / Передати
        </button>
      </div>
    </div>
  );
}

function DisputeCard({ dispute, onDone }) {
  const timer = useCountdown(dispute.dispute_expires_at);
  const [busy, setBusy] = useState('');

  async function resolve(winner) {
    setBusy(winner);
    try {
      await api.post(`/moderation/disputes/${dispute.id}/resolve`, { winner });
      toast.success(`⚖️ Рішення: ${winner === 'executor' ? 'виконавець' : 'замовник'} правий`);
      onDone();
    } catch (err) { toast.error(err.response?.data?.error || 'Помилка'); } finally { setBusy(''); }
  }

  return (
    <div className="card border-red-900/30 animate-slide-up">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <span className="status-badge bg-red-950/50 text-red-400 border-red-900/40 mb-2 inline-block">⚖️ Спір #{dispute.id}</span>
          <h3 className="font-display font-semibold text-zinc-100 text-[15px] leading-snug">{dispute.title}</h3>
        </div>
        <span className="font-display font-bold text-lg text-zinc-200 shrink-0">{formatAmount(dispute.amount)}</span>
      </div>

      {/* Parties */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800">
          <p className="text-xs text-zinc-600 mb-0.5">Замовник</p>
          <p className="text-sm text-zinc-300 font-mono">{dispute.creator_nickname}</p>
        </div>
        <div className="px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800">
          <p className="text-xs text-zinc-600 mb-0.5">Виконавець</p>
          <p className="text-sm text-zinc-300 font-mono">{dispute.executor_nickname}</p>
        </div>
      </div>

      {/* Timer */}
      {timer && (
        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-mono mb-3 ${
          timer.urgent ? 'bg-red-950/30 border-red-900/40 text-red-400' : 'bg-zinc-900 border-zinc-800 text-zinc-500'
        }`}>
          <Clock size={11} className={timer.urgent ? 'animate-pulse' : ''} />
          <span className={timer.urgent ? 'text-red-600' : 'text-zinc-600'}>авто-закриття через:</span>
          <span className="font-bold tabular-nums">{timer.expired ? 'прострочено' : timer.display}</span>
        </div>
      )}

      <p className="text-xs text-zinc-600 mb-3">
        Перегляньте чат та відео-підтвердження через деталі завдання, потім виберіть хто правий:
      </p>

      <div className="flex gap-2">
        <button onClick={() => resolve('executor')} disabled={!!busy}
          className="btn-success flex items-center gap-2 text-sm flex-1 justify-center disabled:opacity-40">
          {busy === 'executor' && <div className="w-3.5 h-3.5 border border-white border-t-transparent rounded-full animate-spin" />}
          ✅ Правий виконавець
        </button>
        <button onClick={() => resolve('creator')} disabled={!!busy}
          className="btn-danger flex items-center gap-2 text-sm flex-1 justify-center disabled:opacity-40">
          {busy === 'creator' && <div className="w-3.5 h-3.5 border border-white border-t-transparent rounded-full animate-spin" />}
          ↩️ Правий замовник
        </button>
      </div>
    </div>
  );
}

export default function ModerationPage() {
  const [queue, setQueue] = useState([]);
  const [disputes, setDisputes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('queue');

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    try {
      const [q, d] = await Promise.all([api.get('/moderation/queue'), api.get('/moderation/disputes')]);
      setQueue(q.data.tasks);
      setDisputes(d.data.disputes);
    } catch { toast.error('Помилка'); } finally { setLoading(false); }
  }

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="section-title flex items-center gap-2"><Shield size={18} /> Модерація</h1>
          <p className="section-sub">Перевіряйте завдання та вирішуйте спори</p>
        </div>
        <button onClick={load} className="btn-ghost flex items-center gap-2 text-sm">
          <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Оновити
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 p-1 rounded-xl bg-zinc-900 border border-zinc-800 w-fit">
        {[['queue','Черга завдань', queue.length], ['disputes','⚖️ Спори', disputes.length]].map(([k,l,cnt]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 ${
              tab === k ? 'bg-zinc-700 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'
            }`}>
            {l}
            {cnt > 0 && (
              <span className={`min-w-[18px] h-[18px] rounded-full text-[10px] font-bold flex items-center justify-center px-1 ${
                tab === k ? 'bg-zinc-500 text-zinc-200' : 'bg-zinc-800 text-zinc-500'
              }`}>{cnt}</span>
            )}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">{[1,2].map((i) => <div key={i} className="h-48 rounded-2xl shimmer-bg" />)}</div>
      ) : tab === 'queue' ? (
        queue.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 size={22} className="text-zinc-600" />
            </div>
            <p className="text-zinc-400 font-display font-semibold">Черга порожня</p>
            <p className="text-zinc-600 text-sm mt-1">Нових завдань для перевірки немає</p>
          </div>
        ) : (
          <div className="space-y-3">
            {queue.map((t) => <TaskModCard key={t.id} task={t} onDone={load} />)}
          </div>
        )
      ) : (
        disputes.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4">
              <Scale size={22} className="text-zinc-600" />
            </div>
            <p className="text-zinc-400 font-display font-semibold">Активних спорів немає</p>
          </div>
        ) : (
          <div className="space-y-3">
            {disputes.map((d) => <DisputeCard key={d.id} dispute={d} onDone={load} />)}
          </div>
        )
      )}
    </div>
  );
}
