import { useState, useEffect } from 'react';
import { BarChart3, Users, DollarSign, CheckSquare, AlertTriangle, RefreshCw, Crown, TrendingUp } from 'lucide-react';
import api from '../utils/api';
import { formatAmount, formatDate } from '../utils/helpers';
import toast from 'react-hot-toast';

function StatCard({ icon: Icon, label, value, sub, accent }) {
  return (
    <div className={`card !p-4 ${accent ? 'border-zinc-600' : ''}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center">
          <Icon size={15} className="text-zinc-400" />
        </div>
      </div>
      <p className="font-display font-bold text-2xl text-zinc-100 tabular-nums">{value}</p>
      <p className="text-xs text-zinc-500 mt-0.5">{label}</p>
      {sub && <p className="text-xs text-zinc-600 mt-0.5">{sub}</p>}
    </div>
  );
}

export default function AdminPage() {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [tab, setTab] = useState('stats');
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    try {
      const [s, u] = await Promise.all([api.get('/admin/stats'), api.get('/admin/users')]);
      setStats(s.data);
      setUsers(u.data.users);
    } catch { toast.error('Помилка завантаження'); } finally { setLoading(false); }
  }

  async function changeRole(userId, newRole) {
    try {
      await api.put(`/admin/users/${userId}/role`, { role: newRole });
      toast.success('Роль оновлено');
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Помилка'); }
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="section-title flex items-center gap-2"><Crown size={18} /> Адмін панель</h1>
          <p className="section-sub">Управління платформою PixieTasks</p>
        </div>
        <button onClick={load} className="btn-ghost flex items-center gap-2 text-sm">
          <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Оновити
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 p-1 rounded-xl bg-zinc-900 border border-zinc-800 w-fit">
        {[['stats','📊 Статистика'],['users','👥 Користувачі']].map(([k,l]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 ${
              tab === k ? 'bg-zinc-700 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'
            }`}>
            {l}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[1,2,3,4,5,6].map((i) => <div key={i} className="h-24 rounded-2xl shimmer-bg" />)}
        </div>
      ) : tab === 'stats' && stats ? (
        <div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
            <StatCard icon={Users}         label="Користувачів"     value={stats.totalUsers} />
            <StatCard icon={BarChart3}     label="Всього завдань"   value={stats.totalTasks} />
            <StatCard icon={TrendingUp}    label="Активних"         value={stats.activeTasks} />
            <StatCard icon={CheckSquare}   label="Завершених"       value={stats.completedTasks}
              sub={stats.totalTasks ? `${Math.round(stats.completedTasks/stats.totalTasks*100)}% успіх` : null} />
            <StatCard icon={AlertTriangle} label="Спорів"           value={stats.disputedTasks} />
            <StatCard icon={DollarSign}    label="Комісій зібрано"  value={formatAmount(stats.totalCommission)} accent />
          </div>
          <div className="card !p-4 text-xs text-zinc-600 font-mono">
            Комісія платформи: 20% з кожного завершеного завдання · Виплачується на карту власника
          </div>
        </div>
      ) : tab === 'users' ? (
        <div className="card !p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800">
                  {['ID','Нікнейм','Роль','Місто','Карта','Дата'].map((h) => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-zinc-600 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-zinc-800/50 hover:bg-zinc-900/60 transition-colors">
                    <td className="px-4 py-3 text-xs text-zinc-700 font-mono">{u.id}</td>
                    <td className="px-4 py-3 font-mono text-zinc-200">{u.nickname}</td>
                    <td className="px-4 py-3">
                      {u.role === 'owner' ? (
                        <span className="status-badge bg-amber-950/50 text-amber-400 border-amber-900/40">👑 Власник</span>
                      ) : (
                        <select value={u.role} onChange={(e) => changeRole(u.id, e.target.value)}
                          className="text-xs bg-zinc-900 border border-zinc-800 rounded-lg px-2 py-1 text-zinc-300 outline-none hover:border-zinc-700 transition-colors cursor-pointer">
                          <option value="user">👤 Користувач</option>
                          <option value="moderator">🛡 Модератор</option>
                        </select>
                      )}
                    </td>
                    <td className="px-4 py-3 text-xs text-zinc-500">{u.city || '—'}</td>
                    <td className="px-4 py-3 text-xs font-mono text-zinc-600">{u.card_masked || '—'}</td>
                    <td className="px-4 py-3 text-xs font-mono text-zinc-700 whitespace-nowrap">{formatDate(u.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}
    </div>
  );
}
