import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import useStore from '../store/useStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [form, setForm] = useState({ nickname: '', password: '' });
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const { setUser, setToken, connectWS } = useStore();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.nickname.trim() || !form.password) return toast.error('Заповніть всі поля');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', form);
      setToken(data.token);
      setUser(data.user);
      connectWS();
      toast.success(`Ласкаво просимо, ${data.user.nickname}!`);
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Помилка входу');
    } finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{background:'#09090b'}}>
      <div className="w-full max-w-sm animate-slide-up">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 items-center justify-center text-2xl mb-4 shadow-xl">⚡</div>
          <h1 className="font-display font-bold text-2xl text-zinc-100 tracking-tight">PixieTasks</h1>
          <p className="text-zinc-500 text-sm mt-1">Платформа мікрозавдань</p>
        </div>

        <div className="card !p-6">
          <h2 className="font-display font-semibold text-lg text-zinc-100 mb-5">Увійти</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Нікнейм</label>
              <input className="input-field" placeholder="your_nickname" value={form.nickname}
                onChange={e => setForm(p => ({...p, nickname: e.target.value}))} autoComplete="username" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Пароль</label>
              <div className="relative">
                <input className="input-field !pr-10" type={showPwd ? 'text' : 'password'}
                  placeholder="••••••••" value={form.password}
                  onChange={e => setForm(p => ({...p, password: e.target.value}))} autoComplete="current-password" />
                <button type="button" onClick={() => setShowPwd(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400 transition-colors">
                  {showPwd ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-accent w-full justify-center !py-3 mt-2">
              {loading ? <div className="w-4 h-4 border-2 border-zinc-500 border-t-zinc-900 rounded-full animate-spin mx-auto" /> : 'Увійти'}
            </button>
          </form>
          <p className="text-center text-zinc-600 text-sm mt-4">
            Немає акаунту?{' '}
            <Link to="/register" className="text-zinc-300 hover:text-white underline underline-offset-2 transition-colors">Зареєструватися</Link>
          </p>
        </div>

        <div className="mt-4 p-3 rounded-xl bg-zinc-900/50 border border-zinc-800">
          <p className="text-xs text-zinc-600 font-mono text-center">Тестові акаунти: <span className="text-zinc-400">Pixie / pixie_admin_2024</span> · <span className="text-zinc-400">Kuga / kuga_mod_2024</span></p>
        </div>
      </div>
    </div>
  );
}
