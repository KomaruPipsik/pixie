import { useNavigate } from 'react-router-dom';
import { Bell, CheckCheck } from 'lucide-react';
import api from '../utils/api';
import useStore from '../store/useStore';
import { formatDate } from '../utils/helpers';

const ICONS = { task: '📋', payment: '💰', dispute: '⚖️', system: '🔔' };

export default function NotificationsPage() {
  const { notifications, unreadCount, markAllRead } = useStore();
  const navigate = useNavigate();

  async function readAll() {
    try { await api.put('/notifications/read'); markAllRead(); } catch {}
  }

  async function click(n) {
    if (!n.is_read) {
      try { await api.put(`/notifications/${n.id}/read`); } catch {}
    }
    if (n.task_id) navigate(`/tasks/${n.task_id}`);
  }

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="section-title">Сповіщення</h1>
          <p className="section-sub">
            {unreadCount > 0 ? `${unreadCount} непрочитаних` : 'Всі прочитано'}
          </p>
        </div>
        {unreadCount > 0 && (
          <button onClick={readAll} className="btn-ghost flex items-center gap-2 text-sm">
            <CheckCheck size={14} /> Прочитати всі
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="text-center py-24">
          <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4">
            <Bell size={22} className="text-zinc-700" />
          </div>
          <p className="text-zinc-500 font-display font-semibold">Сповіщень немає</p>
          <p className="text-zinc-700 text-sm mt-1">Тут з'являться повідомлення про завдання та платежі</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => (
            <button key={n.id} onClick={() => click(n)}
              className={`w-full text-left card card-hover !p-4 transition-all animate-fade-in ${
                !n.is_read ? 'border-zinc-700' : 'opacity-70 hover:opacity-100'
              }`}>
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-base shrink-0 ${
                  !n.is_read ? 'bg-zinc-800' : 'bg-zinc-900/50'
                }`}>
                  {ICONS[n.type] || '🔔'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className={`text-sm font-semibold leading-snug ${!n.is_read ? 'text-zinc-100' : 'text-zinc-500'}`}>
                      {n.title}
                    </p>
                    {!n.is_read && (
                      <div className="w-2 h-2 rounded-full bg-zinc-400 shrink-0 mt-1 animate-pulse-dot" />
                    )}
                  </div>
                  <p className="text-xs text-zinc-500 mt-0.5 line-clamp-2 text-left">{n.body}</p>
                  <p className="text-xs text-zinc-700 font-mono mt-1.5">{formatDate(n.created_at)}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
