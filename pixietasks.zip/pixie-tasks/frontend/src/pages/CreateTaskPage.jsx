import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Info } from 'lucide-react';
import api from '../utils/api';
import useStore from '../store/useStore';
import { CITIES, getSchools } from '../utils/cities';
import toast from 'react-hot-toast';

export default function CreateTaskPage() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [form, setForm] = useState({ title:'', description:'', city: user?.city||'', school: user?.school||'', amount:'' });
  const [loading, setLoading] = useState(false);
  const schools = getSchools(form.city);

  const f = (field) => e => setForm(p => ({...p, [field]: e.target.value}));

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.title.trim()) return toast.error('Введіть назву');
    if (!form.description.trim()) return toast.error('Введіть опис');
    if (!form.city) return toast.error('Оберіть місто');
    if (!form.school) return toast.error('Оберіть школу');
    if (!form.amount || parseFloat(form.amount) < 10) return toast.error('Мінімальна сума — 10 грн');
    setLoading(true);
    try {
      await api.post('/tasks', { ...form, amount: parseFloat(form.amount) });
      toast.success('Завдання відправлено на модерацію!');
      navigate('/my-tasks');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Помилка створення');
    } finally { setLoading(false); }
  }

  return (
    <div className="max-w-xl mx-auto animate-fade-in">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-zinc-500 hover:text-zinc-300 transition-colors mb-6 text-sm">
        <ArrowLeft size={15}/> Назад
      </button>

      <div className="mb-6">
        <h1 className="section-title">Нове завдання</h1>
        <p className="section-sub">Опишіть що потрібно зробити</p>
      </div>

      <div className="card !p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-zinc-400 mb-1.5">Назва завдання *</label>
            <input className="input-field" placeholder="Напр: Помити дошку після уроків" value={form.title} onChange={f('title')} maxLength={80} />
            <p className="text-xs text-zinc-700 mt-1 text-right">{form.title.length}/80</p>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-400 mb-1.5">Повний опис *</label>
            <textarea className="input-field resize-none" rows={4}
              placeholder="Детально опишіть що потрібно зробити, вимоги, час виконання тощо..."
              value={form.description} onChange={f('description')} maxLength={1000} />
            <p className="text-xs text-zinc-700 mt-1 text-right">{form.description.length}/1000</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Місто *</label>
              <select className="input-field !py-2.5 text-sm" value={form.city}
                onChange={e => setForm(p => ({...p, city:e.target.value, school:''}))}>
                <option value="">Оберіть місто</option>
                {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Школа *</label>
              <select className="input-field !py-2.5 text-sm" value={form.school} onChange={f('school')} disabled={!form.city}>
                <option value="">Оберіть школу</option>
                {schools.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-400 mb-1.5">Сума винагороди (грн) *</label>
            <div className="relative">
              <input className="input-field !pr-12" type="number" min="10" step="5" placeholder="50"
                value={form.amount} onChange={f('amount')} />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 text-sm font-mono">грн</span>
            </div>
            <p className="text-xs text-zinc-600 mt-1 flex items-center gap-1"><Info size={11}/>Мінімум 10 грн. Комісія платформи 20%.</p>
          </div>

          <div className="divider" />

          <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-500 space-y-1">
            <p>📋 Після створення завдання пройде перевірку модератора</p>
            <p>💳 Потім вам потрібно внести 100% передоплату для публікації</p>
            <p>⏰ Якщо виконавець не знайдеться за 48 годин — гроші повернуться</p>
          </div>

          <button type="submit" disabled={loading} className="btn-accent w-full !py-3 justify-center">
            {loading ? <div className="w-4 h-4 border-2 border-zinc-600 border-t-zinc-100 rounded-full animate-spin mx-auto" /> : 'Відправити на модерацію'}
          </button>
        </form>
      </div>
    </div>
  );
}
