export const TASK_STATUS = {
  pending_moderation:      { label: 'Очікує модерації',       color: 'bg-yellow-950/50 text-yellow-400 border-yellow-800/40' },
  on_moderation:           { label: 'На перевірці',            color: 'bg-blue-950/50 text-blue-400 border-blue-800/40' },
  approved_awaiting_payment:{ label: 'Потрібна передоплата',  color: 'bg-orange-950/50 text-orange-400 border-orange-800/40' },
  active:                  { label: 'Активне',                 color: 'bg-emerald-950/50 text-emerald-400 border-emerald-800/40' },
  in_progress:             { label: 'Виконується',             color: 'bg-violet-950/50 text-violet-400 border-violet-800/40' },
  pending_confirmation:    { label: 'Чекає підтвердження',     color: 'bg-cyan-950/50 text-cyan-400 border-cyan-800/40' },
  disputed:                { label: '⚖️ Спір',                 color: 'bg-red-950/50 text-red-400 border-red-800/40' },
  completed:               { label: '✅ Завершено',             color: 'bg-zinc-800/60 text-zinc-300 border-zinc-700/40' },
  rejected:                { label: 'Відхилено',               color: 'bg-zinc-900/60 text-zinc-600 border-zinc-800/40' },
  expired:                 { label: 'Час вийшов',              color: 'bg-zinc-900/60 text-zinc-600 border-zinc-800/40' },
};

export function formatAmount(amount) {
  return `${parseFloat(amount || 0).toFixed(0)} ₴`;
}

export function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d)) return '';
  const now = new Date();
  const diff = now - d;
  if (diff < 60000) return 'тільки що';
  if (diff < 3600000) return `${Math.floor(diff / 60000)} хв тому`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} год тому`;
  return d.toLocaleString('uk-UA', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

export function formatDateFull(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d)) return '';
  return d.toLocaleString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function getTimeLeft(expiresAt) {
  if (!expiresAt) return null;
  const diff = new Date(expiresAt) - new Date();
  if (diff <= 0) return { expired: true, display: '00:00:00', urgent: true };
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  const urgent = diff < 4 * 3600000;
  const display = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return { expired: false, display, hours: h, minutes: m, seconds: s, urgent };
}
