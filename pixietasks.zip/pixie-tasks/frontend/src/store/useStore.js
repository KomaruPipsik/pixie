import { create } from 'zustand';
import api from '../utils/api';

const useStore = create((set, get) => ({
  // ── Auth ──────────────────────────────────────────────
  user: null,
  token: localStorage.getItem('token'),

  setUser: (user) => set({ user }),
  setToken: (token) => {
    localStorage.setItem('token', token);
    set({ token });
  },
  logout: () => {
    localStorage.removeItem('token');
    get().disconnectWS();
    set({ user: null, token: null, notifications: [], unreadCount: 0, chatMessages: {}, unreadChats: new Set(), activeChatTaskId: null });
  },

  // ── Notifications ─────────────────────────────────────
  notifications: [],
  unreadCount: 0,

  setNotifications: (notifications, unreadCount) => set({ notifications, unreadCount }),
  addNotification: (notification) => set((s) => ({
    notifications: [notification, ...s.notifications].slice(0, 60),
    unreadCount: s.unreadCount + 1,
  })),
  markAllRead: () => set((s) => ({
    unreadCount: 0,
    notifications: s.notifications.map((n) => ({ ...n, is_read: 1 })),
  })),

  loadNotifications: async () => {
    try {
      const { data } = await api.get('/notifications');
      set({ notifications: data.notifications, unreadCount: data.unreadCount });
    } catch {}
  },

  // ── Chat ──────────────────────────────────────────────
  activeChatTaskId: null,
  chatMessages: {},
  unreadChats: new Set(),

  setActiveChatTaskId: (id) => set({ activeChatTaskId: id }),
  setChatMessages: (taskId, messages) => set((s) => ({
    chatMessages: { ...s.chatMessages, [taskId]: messages },
  })),
  addChatMessage: (taskId, message) => set((s) => ({
    chatMessages: {
      ...s.chatMessages,
      [taskId]: [...(s.chatMessages[taskId] || []), message],
    },
  })),
  markChatRead: (taskId) => set((s) => {
    const next = new Set(s.unreadChats);
    next.delete(taskId);
    return { unreadChats: next };
  }),
  addUnreadChat: (taskId) => set((s) => ({
    unreadChats: new Set([...s.unreadChats, taskId]),
  })),

  // ── WebSocket ─────────────────────────────────────────
  ws: null,
  _wsRetryTimer: null,

  connectWS: () => {
    const token = get().token;
    if (!token || get().ws) return;

    const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
    const wsUrl = `${proto}://${window.location.host}/ws?token=${token}`;
    let ws;
    try { ws = new WebSocket(wsUrl); } catch { return; }

    ws.onopen = () => {
      console.log('[WS] Connected');
      const t = get()._wsRetryTimer;
      if (t) { clearTimeout(t); set({ _wsRetryTimer: null }); }
    };

    ws.onclose = () => {
      set({ ws: null });
      if (get().token) {
        const timer = setTimeout(() => get().connectWS(), 4000);
        set({ _wsRetryTimer: timer });
      }
    };

    ws.onerror = () => ws.close();

    ws.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        const store = get();
        if (data.type === 'notification') {
          store.addNotification(data.notification);
        } else if (data.type === 'new_message') {
          store.addChatMessage(data.taskId, data.message);
          if (data.taskId !== store.activeChatTaskId) {
            store.addUnreadChat(data.taskId);
          }
        } else if (data.type === 'task_update') {
          window.dispatchEvent(new CustomEvent('task_update', { detail: data }));
        }
      } catch {}
    };

    set({ ws });
  },

  disconnectWS: () => {
    const { ws, _wsRetryTimer } = get();
    if (_wsRetryTimer) clearTimeout(_wsRetryTimer);
    if (ws) { try { ws.close(); } catch {} }
    set({ ws: null, _wsRetryTimer: null });
  },

  // ── Bootstrap ─────────────────────────────────────────
  loadMe: async () => {
    try {
      const { data } = await api.get('/auth/me');
      set({ user: data.user });
    } catch {
      get().logout();
    }
  },
}));

export default useStore;
