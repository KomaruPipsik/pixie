import { useState, useEffect, useRef } from 'react';
import { X, Send, Upload, Video, MessageCircle, ChevronDown } from 'lucide-react';
import useStore from '../store/useStore';
import api from '../utils/api';
import { formatDate } from '../utils/helpers';
import toast from 'react-hot-toast';

export default function ChatPanel({ onClose }) {
  const { user, activeChatTaskId, setActiveChatTaskId, chatMessages, setChatMessages,
          addChatMessage, markChatRead, unreadChats } = useStore();
  const [myTasks, setMyTasks] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => { loadMyTasks(); }, []);

  useEffect(() => {
    const m = chatMessages[selectedTask?.id];
    if (m) setMessages(m);
  }, [chatMessages, selectedTask?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (activeChatTaskId && myTasks.length > 0) {
      const t = myTasks.find((t) => t.id === activeChatTaskId);
      if (t) selectTask(t);
    }
  }, [activeChatTaskId, myTasks]);

  async function loadMyTasks() {
    setLoading(true);
    try {
      const { data } = await api.get('/tasks/my');
      const chatTasks = data.tasks.filter(
        (t) => ['in_progress','pending_confirmation','disputed'].includes(t.status) &&
               (t.creator_id === user.id || t.executor_id === user.id)
      );
      setMyTasks(chatTasks);
      if (chatTasks.length > 0 && !selectedTask) selectTask(chatTasks[0]);
    } catch {} finally { setLoading(false); }
  }

  async function selectTask(task) {
    setSelectedTask(task);
    markChatRead(task.id);
    setActiveChatTaskId(task.id);
    if (!chatMessages[task.id]) {
      try {
        const { data } = await api.get(`/messages/${task.id}`);
        setChatMessages(task.id, data.messages);
        setMessages(data.messages);
      } catch {}
    } else {
      setMessages(chatMessages[task.id]);
    }
  }

  async function sendMessage() {
    if (!input.trim() || !selectedTask || sending) return;
    setSending(true);
    try {
      const { data } = await api.post(`/messages/${selectedTask.id}`, { content: input.trim() });
      addChatMessage(selectedTask.id, data.message);
      setInput('');
    } catch { toast.error('Помилка відправки'); } finally { setSending(false); }
  }

  async function uploadVideo(file) {
    if (!selectedTask) return;
    setUploadingVideo(true);
    try {
      const formData = new FormData();
      formData.append('video', file);
      await api.post(`/messages/${selectedTask.id}/video`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      toast.success('Відео завантажено!');
      const { data } = await api.get(`/messages/${selectedTask.id}`);
      setChatMessages(selectedTask.id, data.messages);
      setMessages(data.messages);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Помилка завантаження');
    } finally { setUploadingVideo(false); }
  }

  const isExecutor = selectedTask?.executor_id === user.id;

  return (
    <div
      className="fixed left-4 bottom-[108px] md:bottom-[88px] z-50 w-[340px] md:w-[400px] h-[500px] rounded-2xl flex flex-col animate-slide-up overflow-hidden"
      style={{ background: 'rgba(12,12,14,0.98)', border: '1px solid rgba(63,63,70,0.7)', boxShadow: '0 24px 64px rgba(0,0,0,0.7)' }}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800/80 shrink-0">
        <div className="flex items-center gap-2">
          <MessageCircle size={14} className="text-zinc-500" />
          <span className="font-display text-sm font-semibold text-zinc-200">Чат</span>
          {myTasks.length > 0 && (
            <span className="text-xs text-zinc-600 font-mono">({myTasks.length})</span>
          )}
        </div>
        <button onClick={onClose}
          className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-600 hover:text-zinc-300 transition-colors">
          <X size={14} />
        </button>
      </div>

      {/* Task tabs */}
      {myTasks.length > 1 && (
        <div className="flex gap-1.5 px-3 py-2 border-b border-zinc-800/60 overflow-x-auto no-scrollbar shrink-0">
          {myTasks.map((t) => (
            <button key={t.id} onClick={() => selectTask(t)}
              className={`relative shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedTask?.id === t.id
                  ? 'bg-zinc-700 text-zinc-100'
                  : 'bg-zinc-900 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/80'
              }`}>
              #{t.id} {t.title.slice(0, 12)}…
              {unreadChats.has(t.id) && (
                <span className="notification-dot" style={{ width: '7px', height: '7px' }} />
              )}
            </button>
          ))}
        </div>
      )}

      {/* Body */}
      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="w-5 h-5 border border-zinc-700 border-t-zinc-400 rounded-full animate-spin" />
        </div>
      ) : myTasks.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center px-6">
          <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center">
            <MessageCircle size={20} className="text-zinc-600" />
          </div>
          <div>
            <p className="text-zinc-400 text-sm font-medium">Немає активних завдань</p>
            <p className="text-zinc-700 text-xs mt-1">Чат доступний після взяття завдання в роботу</p>
          </div>
        </div>
      ) : !selectedTask ? (
        <div className="flex-1 flex items-center justify-center">
          <p className="text-zinc-600 text-sm">Оберіть завдання</p>
        </div>
      ) : (
        <>
          {/* Task label */}
          <div className="px-4 py-2 border-b border-zinc-800/60 shrink-0" style={{ background: 'rgba(18,18,21,0.8)' }}>
            <p className="text-xs text-zinc-600 truncate">
              <span className="font-mono text-zinc-700">#{selectedTask.id}</span> · {selectedTask.title}
            </p>
          </div>

          {/* Messages scroll area */}
          <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2">
            {messages.length === 0 && (
              <p className="text-center text-zinc-700 text-xs py-8">Повідомлень поки немає. Напишіть першим!</p>
            )}
            {messages.map((msg) => {
              if (msg.type === 'system') {
                return <div key={msg.id} className="chat-bubble-system">{msg.content}</div>;
              }
              if (msg.type === 'video') {
                const isMe = msg.sender_id === user.id;
                return (
                  <div key={msg.id} className={`flex flex-col gap-1 ${isMe ? 'items-end' : 'items-start'}`}>
                    {!isMe && <span className="text-[10px] text-zinc-600 px-1">{msg.sender_nickname}</span>}
                    <div className={isMe ? 'chat-bubble-me' : 'chat-bubble-other'}>
                      <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-2">
                        <Video size={12} /><span>Відео-підтвердження</span>
                      </div>
                      {msg.video_url ? (
                        <video src={msg.video_url} controls className="rounded-lg max-w-full" style={{ maxHeight: 140 }} />
                      ) : (
                        <div className="px-3 py-2 rounded-lg bg-zinc-800 text-xs text-zinc-500">
                          [відео завантажено на сервер]
                        </div>
                      )}
                    </div>
                    <span className="text-[9px] text-zinc-700 px-1">{formatDate(msg.created_at)}</span>
                  </div>
                );
              }
              const isMe = msg.sender_id === user.id;
              return (
                <div key={msg.id} className={`flex flex-col gap-0.5 ${isMe ? 'items-end' : 'items-start'}`}>
                  {!isMe && <span className="text-[10px] text-zinc-600 px-1">{msg.sender_nickname}</span>}
                  <div className={isMe ? 'chat-bubble-me' : 'chat-bubble-other'}>{msg.content}</div>
                  <span className="text-[9px] text-zinc-700 px-1">{formatDate(msg.created_at)}</span>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Input area */}
          <div className="px-3 pb-3 pt-2 border-t border-zinc-800/80 shrink-0">
            {/* Video upload button (executor only, in_progress) */}
            {isExecutor && selectedTask.status === 'in_progress' && (
              <div className="mb-2">
                <input ref={fileInputRef} type="file" accept="video/*" className="hidden"
                  onChange={(e) => e.target.files[0] && uploadVideo(e.target.files[0])} />
                <button onClick={() => fileInputRef.current?.click()} disabled={uploadingVideo}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-medium text-zinc-500 hover:text-zinc-200 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800/60 transition-all disabled:opacity-40">
                  {uploadingVideo
                    ? <div className="w-3 h-3 border border-zinc-500 border-t-transparent rounded-full animate-spin" />
                    : <Upload size={12} />}
                  {uploadingVideo ? 'Завантаження відео...' : '📹 Завантажити відео-підтвердження'}
                </button>
              </div>
            )}

            <div className="flex gap-2">
              <input value={input} onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                placeholder="Повідомлення..." className="input-field flex-1 !py-2.5 text-sm" />
              <button onClick={sendMessage} disabled={!input.trim() || sending}
                className="btn-primary !py-2 !px-3 disabled:opacity-30 shrink-0">
                {sending
                  ? <div className="w-3.5 h-3.5 border border-zinc-400 border-t-transparent rounded-full animate-spin" />
                  : <Send size={14} />}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
