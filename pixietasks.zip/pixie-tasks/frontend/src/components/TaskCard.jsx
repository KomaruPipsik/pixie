import { useNavigate } from 'react-router-dom';
import { MapPin, School, Clock, User2 } from 'lucide-react';
import { TASK_STATUS, formatAmount, formatDate } from '../utils/helpers';
import { useCountdown } from '../hooks/useCountdown';

export default function TaskCard({ task, showStatus = false }) {
  const navigate = useNavigate();
  const timer = useCountdown(task.timer_expires_at);
  const status = TASK_STATUS[task.status] || { label: task.status, color: 'bg-zinc-800 text-zinc-400 border-zinc-700' };

  return (
    <div className="task-card animate-fade-in group" onClick={() => navigate(`/tasks/${task.id}`)}>
      {/* shimmer line on hover */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-zinc-500/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          {showStatus && (
            <span className={`status-badge ${status.color} mb-2 inline-block`}>{status.label}</span>
          )}
          <h3 className="font-display font-semibold text-zinc-100 text-[15px] leading-snug line-clamp-2 group-hover:text-white transition-colors">{task.title}</h3>
          <div className="flex items-center gap-1.5 mt-1 text-xs text-zinc-600">
            <User2 size={11} />
            <span className="font-mono">{task.creator_nickname}</span>
            <span className="text-zinc-800">·</span>
            <span>{formatDate(task.created_at)}</span>
          </div>
        </div>
        <div className="text-right shrink-0">
          <div className="font-display font-bold text-xl text-zinc-100">{formatAmount(task.amount)}</div>
          <div className="text-xs text-zinc-600 mt-0.5">винагорода</div>
        </div>
      </div>

      <div className="flex items-center gap-4 text-xs text-zinc-500 mb-3">
        <div className="flex items-center gap-1"><MapPin size={11} className="text-zinc-600" />{task.city}</div>
        <div className="flex items-center gap-1"><School size={11} className="text-zinc-600" />{task.school}</div>
      </div>

      <p className="text-zinc-500 text-sm leading-relaxed line-clamp-2 mb-3">{task.description}</p>

      {/* Live countdown timer */}
      {task.status === 'active' && timer && (
        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-mono border transition-colors ${
          timer.urgent
            ? 'bg-red-950/30 border-red-900/40 text-red-500'
            : 'bg-zinc-900 border-zinc-800 text-zinc-500'
        }`}>
          <Clock size={11} className={timer.urgent ? 'animate-pulse' : ''} />
          <span className="text-zinc-600">залишилось:</span>
          <span className={`font-bold tabular-nums tracking-wider ${timer.urgent ? 'animate-timer-urgent' : 'text-zinc-300'}`}>
            {timer.expired ? 'час вийшов' : timer.display}
          </span>
        </div>
      )}

      {/* Executor: appeal window */}
      {task.status === 'in_progress' && task.appeal_expires_at && timer && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-mono border bg-amber-950/30 border-amber-900/40 text-amber-500">
          <Clock size={11} />
          <span className="text-amber-600">апеляція:</span>
          <span className="font-bold tabular-nums">{timer.expired ? 'час вийшов' : timer.display}</span>
        </div>
      )}
    </div>
  );
}
