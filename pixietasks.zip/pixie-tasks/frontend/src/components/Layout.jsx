import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Home, ClipboardList, Bell, User2, Shield, BarChart3, LogOut, MessageCircle, Plus, Zap } from 'lucide-react';
import useStore from '../store/useStore';
import ChatPanel from './ChatPanel';

export default function Layout() {
  const { user, logout, unreadCount, unreadChats } = useStore();
  const navigate = useNavigate();
  const [chatOpen, setChatOpen] = useState(false);
  const hasUnreadChat = unreadChats.size > 0;

  // close chat on route change
  useEffect(() => { setChatOpen(false); }, []);

  function handleLogout() { logout(); navigate('/login'); }

  const navItems = [
    { to: '/',            icon: Home,        label: 'Головна' },
    { to: '/my-tasks',    icon: ClipboardList,label: 'Завдання' },
    { to: '/notifications',icon: Bell,        label: 'Сповіщення', badge: unreadCount },
    { to: '/profile',     icon: User2,        label: 'Профіль' },
  ];
  if (['moderator','owner'].includes(user?.role))
    navItems.push({ to: '/moderation', icon: Shield,    label: 'Модерація' });
  if (user?.role === 'owner')
    navItems.push({ to: '/admin',      icon: BarChart3, label: 'Адмін' });

  return (
    <div className="min-h-screen flex flex-col">
      {/* ── Header ───────────────────────────────── */}
      <header className="sticky top-0 z-40 glass-strong border-b border-zinc-800/80">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
          {/* Logo */}
          <NavLink to="/" className="flex items-center gap-2 shrink-0 group">
            <div className="w-7 h-7 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center group-hover:border-zinc-600 transition-colors">
              <Zap size={14} className="text-zinc-300" />
            </div>
            <span className="font-display font-bold text-[15px] text-zinc-100 tracking-tight">PixieTasks</span>
          </NavLink>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-0.5 flex-1 justify-center">
            {navItems.map(({ to, icon: Icon, label, badge }) => (
              <NavLink key={to} to={to} end={to === '/'}
                className={({ isActive }) =>
                  `relative flex items-center gap-1.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all duration-150 ${
                    isActive
                      ? 'bg-zinc-800 text-zinc-100'
                      : 'text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800/60'
                  }`
                }>
                <Icon size={14} />
                {label}
                {badge > 0 && (
                  <span className="notification-dot" style={{ width: '15px', height: '15px', fontSize: '9px' }}>
                    {badge > 9 ? '9+' : badge}
                  </span>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-2 shrink-0">
            <NavLink to="/tasks/create"
              className="btn-accent flex items-center gap-1.5 !py-1.5 !px-3 text-xs font-semibold">
              <Plus size={13} />
              <span className="hidden sm:inline">Створити</span>
            </NavLink>
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800">
              <div className={`w-1.5 h-1.5 rounded-full ${user?.role === 'owner' ? 'bg-amber-400' : user?.role === 'moderator' ? 'bg-blue-400' : 'bg-zinc-500'}`} />
              <span className="text-xs text-zinc-400 font-mono">{user?.nickname}</span>
            </div>
            <button onClick={handleLogout}
              className="p-2 rounded-lg hover:bg-zinc-800 text-zinc-600 hover:text-zinc-300 transition-colors">
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </header>

      {/* ── Main ─────────────────────────────────── */}
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-6 pb-24 md:pb-8">
        <Outlet />
      </main>

      {/* ── Mobile bottom nav ─────────────────────── */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 glass-strong border-t border-zinc-800/80">
        <div className="flex items-center justify-around h-16 px-2">
          {navItems.slice(0, 4).map(({ to, icon: Icon, label, badge }) => (
            <NavLink key={to} to={to} end={to === '/'}
              className={({ isActive }) =>
                `relative flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition-all duration-150 min-w-[56px] ${
                  isActive ? 'text-zinc-100' : 'text-zinc-600 hover:text-zinc-400'
                }`
              }>
              <Icon size={19} />
              <span className="text-[10px] font-medium leading-none mt-0.5">{label}</span>
              {badge > 0 && (
                <span className="notification-dot" style={{ width: '13px', height: '13px', fontSize: '8px' }}>
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
            </NavLink>
          ))}
        </div>
      </nav>

      {/* ── Chat FAB ──────────────────────────────── */}
      <button
        onClick={() => setChatOpen((v) => !v)}
        className="fixed left-4 bottom-[84px] md:bottom-6 z-50 w-12 h-12 rounded-xl btn-primary flex items-center justify-center shadow-xl animate-float"
        title="Чат"
      >
        <MessageCircle size={18} />
        {hasUnreadChat && (
          <span className="notification-dot" style={{ width: '10px', height: '10px' }} />
        )}
      </button>

      {chatOpen && <ChatPanel onClose={() => setChatOpen(false)} />}
    </div>
  );
}
