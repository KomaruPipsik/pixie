import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import useStore from './store/useStore';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import HomePage from './pages/HomePage';
import TaskDetailPage from './pages/TaskDetailPage';
import CreateTaskPage from './pages/CreateTaskPage';
import MyTasksPage from './pages/MyTasksPage';
import ProfilePage from './pages/ProfilePage';
import ModerationPage from './pages/ModerationPage';
import AdminPage from './pages/AdminPage';
import NotificationsPage from './pages/NotificationsPage';

function Spinner() {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-zinc-950">
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 border-2 border-zinc-700 border-t-zinc-300 rounded-full animate-spin" />
        <p className="text-zinc-600 text-sm font-mono">Завантаження...</p>
      </div>
    </div>
  );
}

function PrivateRoute({ children, role }) {
  const { user, token } = useStore();
  if (!token) return <Navigate to="/login" replace />;
  if (!user) return <Spinner />;
  if (role === 'mod' && !['moderator','owner'].includes(user.role)) return <Navigate to="/" replace />;
  if (role === 'owner' && user.role !== 'owner') return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { token, loadMe, connectWS, loadNotifications } = useStore();

  useEffect(() => {
    if (token) {
      loadMe();
      loadNotifications();
      connectWS();
    }
  }, [token]);

  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        gutter={8}
        toastOptions={{
          duration: 4000,
          style: {
            background: 'rgba(24,24,27,0.98)',
            color: '#e4e4e7',
            border: '1px solid rgba(63,63,70,0.8)',
            backdropFilter: 'blur(20px)',
            fontFamily: '"Inter", sans-serif',
            fontSize: '13px',
            borderRadius: '12px',
            padding: '12px 16px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
          },
          success: { iconTheme: { primary: '#10b981', secondary: '#18181b' } },
          error:   { iconTheme: { primary: '#ef4444', secondary: '#18181b' } },
        }}
      />
      <Routes>
        <Route path="/login"    element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
          <Route index element={<HomePage />} />
          <Route path="tasks/create" element={<CreateTaskPage />} />
          <Route path="tasks/:id"    element={<TaskDetailPage />} />
          <Route path="my-tasks"     element={<MyTasksPage />} />
          <Route path="notifications" element={<NotificationsPage />} />
          <Route path="profile"      element={<ProfilePage />} />
          <Route path="moderation"   element={<PrivateRoute role="mod"><ModerationPage /></PrivateRoute>} />
          <Route path="admin"        element={<PrivateRoute role="owner"><AdminPage /></PrivateRoute>} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
